//! Guardian-owned closed gate. Only exact local owner and physical pane peers.
use super::*;
use crate::local_ipc::Socket;
use std::os::fd::AsRawFd;
use std::os::unix::fs::FileTypeExt;
const NAME: &str = "observed-gate.sock";
#[derive(Serialize, Deserialize)]
#[serde(tag = "kind", deny_unknown_fields)]
enum Request {
    Admit {
        guardian: GuardianIdentity,
    },
    Hello {
        guardian: GuardianIdentity,
        process: ProcessEvidence,
        columns: u16,
        rows: u16,
    },
    Status {
        baseline_id: Uuid,
    },
    Confirm {
        baseline_id: Uuid,
    },
    Release {
        baseline_digest: Digest,
    },
}
#[derive(Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub(crate) struct ClosedReady {
    pub guardian: GuardianIdentity,
    pub pane: PaneIdentity,
    pub baseline_id: Uuid,
    pub columns: u16,
    pub rows: u16,
    pub helper_ready_boot_ms: u64,
}
#[derive(Serialize, Deserialize)]
#[serde(tag = "kind", deny_unknown_fields)]
enum Response {
    Admitted,
    Waiting,
    Closed {
        ready: ClosedReady,
    },
    Baseline {
        baseline: BlankBaselineRecord,
    },
    Released,
    Execute {
        guardian: GuardianIdentity,
        baseline_id: Uuid,
    },
}
pub(crate) struct Owner {
    listener: Socket,
    path: PathBuf,
    inode: (u64, u64),
    pending: Option<Socket>,
    control: Option<Socket>,
    helper: Option<Socket>,
    image: Option<File>,
    ready: Option<ClosedReady>,
    baseline: Option<BlankBaselineRecord>,
    released: bool,
}
pub(crate) struct GateTurn<'a> {
    pub(crate) config: &'a SealedLaunch,
    pub(crate) host: &'a HostObservation,
    pub(crate) directory: &'a Path,
    pub(crate) readers: &'a reader_lease::Owner,
    pub(crate) guard: &'a terminal_io::DirectoryGuard,
}
struct Admission {
    guardian: GuardianIdentity,
    peer_pid: u32,
    fd: Option<std::os::fd::OwnedFd>,
}
struct Hello {
    guardian: GuardianIdentity,
    process: ProcessEvidence,
    columns: u16,
    rows: u16,
    peer_pid: u32,
    no_fd: bool,
}
impl Hello {
    fn matches_pane(&self, pane: &PaneIdentity, spec: &Spec) -> Result<bool> {
        Ok(self.process == pane.pane
            && self.peer_pid == self.process.pid
            && ownership::process_evidence(self.process.pid)? == self.process
            && self.columns == spec.columns
            && self.rows == spec.rows)
    }
}

impl Owner {
    pub(crate) fn new(directory: &Path) -> Result<Self> {
        let path = directory.join(NAME);
        let listener = Socket::new()?;
        let (address, length) = Socket::address(&path)?;
        ensure!(
            unsafe {
                libc::bind(
                    listener.raw(),
                    (&address as *const libc::sockaddr_un).cast(),
                    length,
                )
            } == 0,
            "observed gate socket collision"
        );
        std::fs::set_permissions(&path, std::fs::Permissions::from_mode(0o600))?;
        ensure!(
            unsafe { libc::listen(listener.raw(), 2) } == 0,
            "observed gate listen"
        );
        let metadata = std::fs::symlink_metadata(&path)?;
        Ok(Self {
            listener,
            path,
            inode: (metadata.dev(), metadata.ino()),
            pending: None,
            control: None,
            helper: None,
            image: None,
            ready: None,
            baseline: None,
            released: false,
        })
    }
    pub(crate) fn closed_ready(&self) -> Option<&ClosedReady> {
        self.ready.as_ref()
    }
    pub(crate) fn tick(&mut self, turn: &GateTurn<'_>) -> Result<bool> {
        turn.guard.verify()?;
        let spec = turn
            .config
            .observed
            .as_ref()
            .context("missing observed specification")?;
        let metadata = std::fs::symlink_metadata(&self.path)?;
        ensure!(
            metadata.file_type().is_socket()
                && metadata.mode() & 0o777 == 0o600
                && metadata.uid() == unsafe { libc::geteuid() }
                && (metadata.dev(), metadata.ino()) == self.inode,
            "observed gate socket replaced"
        );
        ensure!(
            ownership::raw_boot_ms() < turn.host.permit_deadline_boot_ms
                && ownership::raw_boot_ms() < turn.config.wall_deadline()?,
            "observed gate authority expired"
        );
        if self.released {
            let pane = &self.ready.as_ref().context("released pane missing")?.pane;
            let helper = self.helper.as_ref().context("released helper missing")?;
            return released(helper, pane, &spec.program);
        }
        self.accept(turn, spec)?;
        self.control(turn, spec)?;
        // The helper stays blocked here. EOF, client loss and every malformed
        // packet fail closed; the guardian's independent stop path reaps it.
        if !self.released
            && let Some(helper) = self.helper.as_ref()
        {
            ensure!(
                helper.receive()?.is_none(),
                "unexpected closed helper packet"
            );
        }
        Ok(false)
    }

    fn accept(&mut self, turn: &GateTurn<'_>, spec: &Spec) -> Result<()> {
        if self.pending.is_none() {
            self.pending = self.listener.accept()?;
        }
        if let Some(socket) = self.pending.as_ref()
            && let Some(packet) = socket.receive()?
        {
            let peer = socket.credentials()?;
            match serde_json::from_slice::<Request>(&packet.bytes)? {
                Request::Admit { guardian } => {
                    self.admit(
                        turn,
                        spec,
                        Admission {
                            guardian,
                            peer_pid: peer.pid as u32,
                            fd: packet.fd,
                        },
                    )?;
                }
                Request::Hello {
                    guardian,
                    process,
                    columns,
                    rows,
                } => {
                    self.hello(
                        turn,
                        spec,
                        Hello {
                            guardian,
                            process,
                            columns,
                            rows,
                            peer_pid: peer.pid as u32,
                            no_fd: packet.fd.is_none(),
                        },
                    )?;
                }
                _ => bail!("observed gate first packet refused"),
            }
        }
        Ok(())
    }
    fn admit(&mut self, turn: &GateTurn<'_>, spec: &Spec, registration: Admission) -> Result<()> {
        let Admission {
            guardian,
            peer_pid,
            fd,
        } = registration;
        ensure!(
            guardian == turn.host.guardian
                && peer_pid == spec.owner.pid
                && ownership::process_evidence(spec.owner.pid)? == spec.owner
                && self.control.is_none()
                && self.image.is_none()
                && turn.host.phase == HostPhase::Waiting,
            "observed program owner/admission mismatch"
        );
        let file = File::from(fd.context("observed program descriptor missing")?);
        executable::verify_file(&file, &spec.program)?;
        self.pending
            .as_ref()
            .context("admission socket absent")?
            .send(&Response::Admitted, None)?;
        self.image = Some(file);
        self.control = self.pending.take();
        Ok(())
    }
    fn hello(&mut self, turn: &GateTurn<'_>, spec: &Spec, hello: Hello) -> Result<()> {
        let pane = turn
            .host
            .pane
            .as_ref()
            .context("observed pane not established")?;
        ensure!(
            hello.no_fd
                && hello.guardian == turn.host.guardian
                && turn.host.phase == HostPhase::Starting
                && self.image.is_some()
                && self.helper.is_none()
                && hello.matches_pane(pane, spec)?,
            "observed helper identity/geometry mismatch"
        );
        let Hello {
            guardian,
            columns,
            rows,
            ..
        } = hello;
        self.ready = Some(ClosedReady {
            guardian,
            pane: pane.clone(),
            baseline_id: spec.baseline_id,
            columns,
            rows,
            helper_ready_boot_ms: ownership::raw_boot_ms(),
        });
        self.helper = self.pending.take();
        Ok(())
    }
    fn control(&mut self, turn: &GateTurn<'_>, spec: &Spec) -> Result<()> {
        if let Some(socket) = self.control.as_ref()
            && let Some(packet) = socket.receive()?
        {
            ensure!(
                packet.fd.is_none(),
                "unexpected observed control descriptor"
            );
            match serde_json::from_slice::<Request>(&packet.bytes)? {
                Request::Status { baseline_id } => {
                    ensure!(
                        baseline_id == spec.baseline_id,
                        "observed baseline mismatch"
                    );
                    socket.send(
                        &self
                            .ready
                            .as_ref()
                            .map_or(Response::Waiting, |ready| Response::Closed {
                                ready: ready.clone(),
                            }),
                        None,
                    )?;
                }
                Request::Confirm { baseline_id } => {
                    self.confirm(turn, spec, baseline_id)?;
                }
                Request::Release { baseline_digest } => {
                    self.release(turn, spec, baseline_digest)?;
                }
                _ => bail!("observed control operation refused"),
            }
        }
        Ok(())
    }
    fn confirm(&mut self, turn: &GateTurn<'_>, spec: &Spec, baseline_id: Uuid) -> Result<()> {
        let socket = self
            .control
            .as_ref()
            .context("observed control socket absent")?;
        ensure!(
            baseline_id == spec.baseline_id,
            "observed baseline mismatch"
        );
        let ready = self.ready.as_ref().context("closed helper missing")?;
        verify_closed(turn.config, turn.host, ready, turn.directory)?;
        if !turn.readers.drained_after(ready.helper_ready_boot_ms) {
            socket.send(&Response::Waiting, None)?;
        } else {
            let baseline = self.baseline.get_or_insert_with(|| BlankBaselineRecord {
                ready: ready.clone(),
                terminal: spec.terminal.clone(),
                renderer: spec.renderer.clone(),
                configuration_digest: turn.host.guardian.intent.configuration_digest.clone(),
            });
            socket.send(
                &Response::Baseline {
                    baseline: baseline.clone(),
                },
                None,
            )?;
        }
        Ok(())
    }
    fn release(&mut self, turn: &GateTurn<'_>, spec: &Spec, baseline_digest: Digest) -> Result<()> {
        let socket = self
            .control
            .as_ref()
            .context("observed control socket absent")?;
        let ready = self.ready.as_ref().context("closed helper missing")?;
        verify_closed(turn.config, turn.host, ready, turn.directory)?;
        let baseline = self.baseline.as_ref().context("baseline not confirmed")?;
        let baseline_bytes = serde_json::to_vec(baseline)?;
        ensure!(
            Digest::of(&baseline_bytes) == baseline_digest,
            "baseline release digest mismatch"
        );
        ensure!(
            turn.readers.drained_after(ready.helper_ready_boot_ms),
            "baseline release reader lease missing or undrained"
        );
        turn.guard.verify()?;
        durable_new(&turn.directory.join("pane-exec.claim"), &baseline_bytes)?;
        turn.guard.verify()?;
        verify_closed(turn.config, turn.host, ready, turn.directory)?;
        ensure!(
            turn.readers.drained_after(ready.helper_ready_boot_ms),
            "reader lost during release persistence"
        );
        self.released = true; // No second release even if delivery/ACK is uncertain.
        self.helper
            .as_ref()
            .context("closed helper missing")?
            .send(
                &Response::Execute {
                    guardian: turn.host.guardian.clone(),
                    baseline_id: spec.baseline_id,
                },
                Some(
                    self.image
                        .as_ref()
                        .context("sealed image missing")?
                        .as_raw_fd(),
                ),
            )?;
        socket.send(&Response::Released, None)?;
        #[cfg(feature = "test-support")]
        supervisor::fault_point(turn.directory, "observed-exec-permit")?;
        Ok(())
    }
}
/// `Ok(true)` only on helper hang-up plus exec evidence for the sealed image.
fn released(helper: &Socket, pane: &PaneIdentity, program: &ElfIdentity) -> Result<bool> {
    if helper.hung_up()? {
        exec::live_pane(pane)?;
        exec::observed_image(&pane.pane, program)?;
        return Ok(true);
    }
    released_read(helper)?;
    Ok(false)
}
/// Exec can close the helper's CLOEXEC socket after the hang-up poll; that EOF
/// defers to the next tick's exec evidence. Any packet still fails closed.
fn released_read(helper: &Socket) -> Result<()> {
    match helper.receive_or_eof()? {
        None => Ok(()),
        Some(packet) if !packet_has_payload(&packet) && helper.hung_up()? => Ok(()),
        Some(_) => bail!("unexpected released helper packet"),
    }
}
fn packet_has_payload(packet: &crate::local_ipc::Packet) -> bool {
    !packet.bytes.is_empty() || packet.fd.is_some()
}

fn verify_closed(
    config: &SealedLaunch,
    host: &HostObservation,
    ready: &ClosedReady,
    directory: &Path,
) -> Result<()> {
    ensure!(
        host.phase == HostPhase::Starting
            && host.guardian == ready.guardian
            && host.pane.as_ref() == Some(&ready.pane)
            && ownership::raw_boot_ms() < host.permit_deadline_boot_ms
            && ownership::raw_boot_ms() < config.wall_deadline()?
            && !directory.join("stop.request").exists(),
        "closed baseline authority/identity changed"
    );
    exec::live_pane(&ready.pane)?;
    ensure!(
        ownership::process_evidence(ready.pane.pane.pid)? == ready.pane.pane,
        "closed helper incarnation changed"
    );
    let current = std::fs::metadata(format!("/proc/{}/exe", ready.pane.pane.pid))?;
    let expected = std::fs::metadata(&config.helper)?;
    ensure!(
        (current.dev(), current.ino()) == (expected.dev(), expected.ino()),
        "closed helper executable changed"
    );
    let stdin = OpenOptions::new()
        .read(true)
        .custom_flags(libc::O_NONBLOCK | libc::O_NOCTTY | libc::O_CLOEXEC)
        .open(format!("/proc/{}/fd/0", ready.pane.pane.pid))?;
    let mut size: libc::winsize = unsafe { std::mem::zeroed() };
    ensure!(
        unsafe { libc::ioctl(stdin.as_raw_fd(), libc::TIOCGWINSZ, &mut size) } == 0
            && size.ws_col == ready.columns
            && size.ws_row == ready.rows,
        "closed pane geometry changed"
    );
    Ok(())
}
pub(crate) struct Client {
    socket: Socket,
}
impl Client {
    pub(crate) fn admit(
        directory: &Path,
        guardian: &GuardianIdentity,
        program: &ObservedProgram,
        deadline: u64,
    ) -> Result<Self> {
        let socket = Socket::connect(&directory.join(NAME))?;
        ensure!(
            socket.credentials()?.pid as u32 == guardian.process.pid
                && ownership::process_evidence(guardian.process.pid)? == guardian.process,
            "observed guardian peer mismatch"
        );
        socket.send(
            &Request::Admit {
                guardian: guardian.clone(),
            },
            Some(program.file().as_raw_fd()),
        )?;
        loop {
            if let Some(packet) = socket.receive()? {
                ensure!(
                    packet.fd.is_none()
                        && matches!(
                            serde_json::from_slice::<Response>(&packet.bytes)?,
                            Response::Admitted
                        ),
                    "observed program acknowledgement mismatch"
                );
                return Ok(Self { socket });
            }
            ensure!(
                ownership::raw_boot_ms() < deadline,
                "observed admission deadline"
            );
            std::thread::sleep(Duration::from_millis(2));
        }
    }
    fn exchange(&self, request: &Request, deadline: u64) -> Result<Response> {
        ensure!(
            ownership::raw_boot_ms() < deadline,
            "observed command deadline"
        );
        self.socket.send(request, None)?;
        loop {
            if let Some(packet) = self.socket.receive()? {
                ensure!(
                    packet.fd.is_none(),
                    "unexpected observed control reply descriptor"
                );
                return Ok(serde_json::from_slice(&packet.bytes)?);
            }
            ensure!(
                ownership::raw_boot_ms() < deadline,
                "observed reply deadline"
            );
            std::thread::sleep(Duration::from_millis(2));
        }
    }
    pub(crate) fn confirm(
        &self,
        baseline_id: Uuid,
        deadline: u64,
    ) -> Result<Option<VerifiedBlankBaseline>> {
        match self.exchange(&Request::Confirm { baseline_id }, deadline)? {
            Response::Waiting => Ok(None),
            Response::Baseline { baseline } => Ok(Some(VerifiedBlankBaseline(baseline))),
            _ => bail!("unexpected baseline response"),
        }
    }
    pub(crate) fn release(&self, baseline_digest: Digest, deadline: u64) -> Result<()> {
        ensure!(
            matches!(
                self.exchange(&Request::Release { baseline_digest }, deadline)?,
                Response::Released
            ),
            "unexpected release response"
        );
        Ok(())
    }
    pub(crate) fn closed(&self, baseline_id: Uuid, deadline: u64) -> Result<Option<ClosedReady>> {
        self.socket.send(&Request::Status { baseline_id }, None)?;
        loop {
            if let Some(packet) = self.socket.receive()? {
                ensure!(packet.fd.is_none(), "unexpected observed reply descriptor");
                return match serde_json::from_slice(&packet.bytes)? {
                    Response::Waiting => Ok(None),
                    Response::Closed { ready } => Ok(Some(ready)),
                    _ => bail!("unexpected observed gate response"),
                };
            }
            ensure!(
                ownership::raw_boot_ms() < deadline,
                "observed status deadline"
            );
            std::thread::sleep(Duration::from_millis(2));
        }
    }
}
/// Dedicated pane helper; no terminal bytes before release. The first component
/// releases only on the guardian's exact baseline/reader-checked FD permit.
pub(crate) fn wait_closed(
    directory: &Path,
    config: &SealedLaunch,
    guardian: &GuardianIdentity,
    server: &ProcessEvidence,
) -> Result<()> {
    let spec = config
        .observed
        .as_ref()
        .context("observed helper configuration")?;
    let launch = exec::PaneLaunch {
        directory,
        config,
        guardian,
        server,
    };
    let socket = helper_socket(directory, guardian)?;
    loop {
        ensure!(
            launch.permit_live()?,
            "observed helper original authority expired"
        );
        if let Some(packet) = socket.receive()? {
            return launch.release(spec, packet);
        }
        std::thread::sleep(Duration::from_millis(5));
    }
}

fn helper_socket(directory: &Path, guardian: &GuardianIdentity) -> Result<Socket> {
    let socket = Socket::connect(&directory.join(NAME))?;
    ensure!(
        socket.credentials()?.pid as u32 == guardian.process.pid
            && ownership::process_evidence(guardian.process.pid)? == guardian.process,
        "observed helper guardian mismatch"
    );
    let mut size: libc::winsize = unsafe { std::mem::zeroed() };
    ensure!(
        unsafe { libc::ioctl(libc::STDIN_FILENO, libc::TIOCGWINSZ, &mut size) } == 0,
        "observed helper terminal geometry"
    );
    socket.send(
        &Request::Hello {
            guardian: guardian.clone(),
            process: ownership::process_evidence(std::process::id())?,
            columns: size.ws_col,
            rows: size.ws_row,
        },
        None,
    )?;
    Ok(socket)
}

impl exec::PaneLaunch<'_> {
    fn release(&self, spec: &Spec, packet: crate::local_ipc::Packet) -> Result<()> {
        let Response::Execute {
            guardian: released,
            baseline_id,
        } = serde_json::from_slice(&packet.bytes)?
        else {
            bail!("observed helper release operation refused")
        };
        ensure!(
            released == *self.guardian && baseline_id == spec.baseline_id,
            "observed helper release identity mismatch"
        );
        let file = File::from(
            packet
                .fd
                .context("observed helper sealed descriptor missing")?,
        );
        executable::verify_file(&file, &spec.program)?;
        let rendered = self
            .config
            .rendered_startup
            .as_ref()
            .context("observed rendered payload missing")?;
        rendered.verify(
            self.config.manifest.task()?,
            &read_bytes(&self.directory.join("context-0.bin"), 1_048_576)?,
        )?;
        ensure!(
            self.permit_live()? && supervisor::guardian_live(self.guardian),
            "authority expired immediately before sealed exec"
        );
        ensure!(
            ownership::pidfd_is_live(&ownership::verified_pidfd(self.server)?)?,
            "owned server lost immediately before sealed exec"
        );
        let startup_stdin = exec::startup_stdin(self.config, self.directory)?;
        self.enter(&file, &spec.program, startup_stdin.as_ref())
    }
}
#[cfg(test)]
mod tests {
    use super::*;
    use std::os::fd::{FromRawFd, OwnedFd};
    fn pair() -> (Socket, Socket) {
        let mut fds = [0; 2];
        let flags = libc::SOCK_SEQPACKET | libc::SOCK_CLOEXEC | libc::SOCK_NONBLOCK;
        assert_eq!(
            unsafe { libc::socketpair(libc::AF_UNIX, flags, 0, fds.as_mut_ptr()) },
            0
        );
        unsafe {
            (
                Socket(OwnedFd::from_raw_fd(fds[0])),
                Socket(OwnedFd::from_raw_fd(fds[1])),
            )
        }
    }
    #[test]
    fn released_helper_closing_after_the_hang_up_poll_defers_to_exec_evidence() {
        let process = ownership::process_evidence(std::process::id()).unwrap();
        let pane = PaneIdentity {
            server: process.clone(),
            pane: process,
            pane_id: "%0".into(),
            session_name: "aq".into(),
        };
        let exe = std::fs::metadata("/proc/self/exe").unwrap();
        let mut image = ElfIdentity {
            artifact: ArtifactRef {
                id: aq_session_protocol::Text::new("synthetic").unwrap(),
                version: aq_session_protocol::Text::new("1").unwrap(),
                digest: Digest::of(b"synthetic"),
            },
            bytes: 128,
            device: exe.dev(),
            inode: exe.ino() + 1,
            profile: None,
        };
        // The helper's exec closes its end between the guardian's poll and its read.
        let (guardian, helper) = pair();
        assert!(!guardian.hung_up().unwrap());
        drop(helper);
        assert!(guardian.receive().is_err(), "the strict read refuses EOF");
        released_read(&guardian).unwrap();
        // The next tick still fails closed without exec evidence for the sealed image.
        assert!(released(&guardian, &pane, &image).is_err());
        image.inode = exe.ino();
        assert!(released(&guardian, &pane, &image).unwrap());
        // A live helper sending anything after release fails closed, even an empty packet.
        let (guardian, helper) = pair();
        assert!(!released(&guardian, &pane, &image).unwrap());
        assert_eq!(
            unsafe { libc::send(helper.raw(), std::ptr::null(), 0, 0) },
            0
        );
        assert!(released_read(&guardian).is_err());
        helper.send(&Response::Released, None).unwrap();
        assert!(released_read(&guardian).is_err());
    }
}
