//! The node's authenticated link to aq-server (bearer, optional Cloudflare Access).
use crate::enrollment_file::EnrollmentFile;
use anyhow::{Context, Result, bail, ensure};
use aq_protocol::{ControlResponse, HandoffNotice, SlotsRequest, SlotsResponse, valid_machine_key};
use reqwest::header;
use serde::{Serialize, de::DeserializeOwned};
use std::time::Duration;
use zeroize::Zeroizing;

pub type TerminalStream =
    tokio_tungstenite::WebSocketStream<tokio_tungstenite::MaybeTlsStream<tokio::net::TcpStream>>;

pub struct ServerLink {
    origin: url::Url,
    credential: Zeroizing<String>,
    access: Option<(String, Zeroizing<String>)>,
    http: reqwest::Client,
    control_schema: std::sync::atomic::AtomicU32,
}
/// The error of a non-2xx response; callers find it with `e.downcast_ref::<LinkError>()`.
#[derive(Debug, thiserror::Error)]
#[error("server answered {status}{}", code.as_deref().map(|c| format!(" ({c})")).unwrap_or_default())]
pub struct LinkError {
    pub status: u16,
    pub code: Option<String>,
}
impl LinkError {
    /// AQ itself refused the credential: 401 or 403 in AQ's own error schema.
    pub fn revoked(&self) -> bool {
        matches!(self.status, 401 | 403) && self.code.is_some()
    }
    /// A redirect, or a 401/403 without AQ's schema: an edge in front of AQ (Cloudflare
    /// Access) refused the request. That is a misconfigured Access token, never a revoke.
    pub fn edge_refused(&self) -> bool {
        (300..400).contains(&self.status)
            || (matches!(self.status, 401 | 403) && self.code.is_none())
    }
}
/// The node's server-origin rule: https to any host, plain http only to 127.0.0.1 or ::1;
/// no userinfo, query, fragment or path.
pub fn checked_origin(origin: &str) -> Result<url::Url> {
    let origin = url::Url::parse(origin).map_err(|_| anyhow::anyhow!("invalid server origin"))?;
    ensure!(
        secure_transport(&origin),
        "the server origin must be https (plain http only to 127.0.0.1 or ::1)"
    );
    ensure!(
        origin.host_str().is_some()
            && origin.username().is_empty()
            && origin.password().is_none()
            && origin.path() == "/"
            && origin.query().is_none()
            && origin.fragment().is_none(),
        "the server origin must be a bare scheme://host[:port]"
    );
    Ok(origin)
}
fn secure_transport(origin: &url::Url) -> bool {
    let local = match origin.host() {
        Some(url::Host::Ipv4(ip)) => ip == std::net::Ipv4Addr::LOCALHOST,
        Some(url::Host::Ipv6(ip)) => ip.is_loopback(),
        _ => false,
    };
    origin.scheme() == "https" || (origin.scheme() == "http" && local)
}

impl ServerLink {
    /// A bounded, original-node WebSocket. Never follows a redirect or exposes credentials to a sandbox.
    pub async fn terminal_stream(&self, id: uuid::Uuid) -> Result<TerminalStream> {
        self.terminal_stream_path(&format!("/v1/worker/manual-agents/{id}/terminal-stream"))
            .await
    }
    /// The live terminal of a queued attempt this node runs.
    pub async fn attempt_terminal_stream(&self, id: uuid::Uuid) -> Result<TerminalStream> {
        self.terminal_stream_path(&format!(
            "/v1/worker/attempt-terminals/{id}/terminal-stream"
        ))
        .await
    }
    pub async fn host_terminal_stream(&self, id: uuid::Uuid) -> Result<TerminalStream> {
        self.terminal_stream_path(&format!("/v1/worker/host-terminals/{id}/terminal-stream"))
            .await
    }
    pub async fn host_terminal_poll(&self, body: &serde_json::Value) -> Result<serde_json::Value> {
        self.post("/v1/worker/host-terminals", body).await
    }
    async fn terminal_stream_path(&self, path: &str) -> Result<TerminalStream> {
        use tokio_tungstenite::tungstenite::client::IntoClientRequest;
        let mut url = self.origin.join(path)?;
        let scheme = if url.scheme() == "https" { "wss" } else { "ws" };
        url.set_scheme(scheme)
            .map_err(|_| anyhow::anyhow!("invalid stream origin"))?;
        let mut request = url
            .as_str()
            .into_client_request()
            .map_err(|_| anyhow::anyhow!("invalid terminal stream request"))?;
        let mut bearer = header::HeaderValue::from_str(&format!("Bearer {}", &*self.credential))
            .map_err(|_| anyhow::anyhow!("invalid node credential"))?;
        bearer.set_sensitive(true);
        request.headers_mut().insert(header::AUTHORIZATION, bearer);
        if let Some((id, secret)) = &self.access {
            let mut value = header::HeaderValue::from_str(secret)
                .map_err(|_| anyhow::anyhow!("invalid Access secret"))?;
            value.set_sensitive(true);
            request
                .headers_mut()
                .insert("cf-access-client-id", header::HeaderValue::from_str(id)?);
            request
                .headers_mut()
                .insert("cf-access-client-secret", value);
        }
        let config = tokio_tungstenite::tungstenite::protocol::WebSocketConfig::default()
            .max_message_size(Some(131072))
            .max_frame_size(Some(131072));
        tokio::time::timeout(
            Duration::from_secs(10),
            tokio_tungstenite::connect_async_with_config(request, Some(config), false),
        )
        .await
        .map_err(|_| anyhow::anyhow!("terminal stream handshake timed out"))?
        .map(|(socket, _)| socket)
        .map_err(|_| anyhow::anyhow!("terminal stream handshake refused"))
    }
    pub async fn manual_poll(&self, body: &serde_json::Value) -> Result<serde_json::Value> {
        self.post("/v1/worker/manual-agents", body).await
    }
    pub async fn manual_conversation(
        &self,
        id: uuid::Uuid,
        body: &serde_json::Value,
    ) -> Result<serde_json::Value> {
        self.post(&format!("/v1/worker/manual-agents/{id}/conversation"), body)
            .await
    }
    pub async fn attempt_conversation(
        &self,
        attempt: uuid::Uuid,
        body: &serde_json::Value,
    ) -> Result<serde_json::Value> {
        self.post(&format!("/v1/worker/attempts/{attempt}/conversation"), body)
            .await
    }
    /// Refuses an origin outside `checked_origin`'s rule and an empty or non-ASCII credential.
    pub fn new(origin: &str, credential: &str, access: Option<(&str, &str)>) -> Result<Self> {
        let origin = checked_origin(origin)?;
        ensure!(
            !credential.is_empty() && credential.bytes().all(|b| b.is_ascii_graphic()),
            "invalid node credential"
        );
        let http = reqwest::Client::builder()
            .timeout(Duration::from_secs(10))
            .redirect(reqwest::redirect::Policy::none())
            .build()
            .context("build HTTP client")?;
        Ok(Self {
            origin,
            credential: Zeroizing::new(credential.to_owned()),
            access: access.map(|(id, secret)| (id.to_owned(), Zeroizing::new(secret.to_owned()))),
            http,
            control_schema: std::sync::atomic::AtomicU32::new(
                aq_protocol::NODE_SLOTS_SCHEMA_VERSION,
            ),
        })
    }
    pub fn from_enrollment(file: &EnrollmentFile) -> Result<Self> {
        let access = match (&file.cf_client_id, &file.cf_client_secret) {
            (Some(id), Some(secret)) => Some((id.as_str(), secret.as_str())),
            (None, None) => None,
            _ => bail!("Access client id and secret must both be set"),
        };
        Self::new(&file.server_url, &file.credential, access)
    }
    pub async fn slots(&self, req: &SlotsRequest) -> Result<SlotsResponse> {
        self.post("/v1/worker/slots", req).await
    }
    pub async fn control(&self) -> Result<ControlResponse> {
        use std::sync::atomic::Ordering;
        let version = self.control_schema.load(Ordering::SeqCst);
        let (reply, version) = negotiate_control(version, |schema| async move {
            self.post(
                "/v1/worker/control",
                &serde_json::json!({"schema_version": schema}),
            )
            .await
        })
        .await?;
        self.control_schema.store(version, Ordering::SeqCst);
        Ok(reply)
    }
    pub async fn handoff(&self, notice: &HandoffNotice) -> Result<()> {
        self.post::<_, serde_json::Value>("/v1/worker/handoffs", notice)
            .await
            .map(drop)
    }
    /// D2 ruling C: releases an attempt whose host was lost, with an outside stop proof.
    pub async fn lost_attempt(
        &self,
        r: &aq_protocol::LostAttemptRelease,
    ) -> Result<aq_protocol::LostAttemptReleased> {
        self.post("/v1/worker/lost-attempts", r).await
    }
    pub async fn machine_report<T: Serialize + Sync>(&self, report: &T) -> Result<()> {
        self.post::<_, serde_json::Value>("/v1/worker/machine", report)
            .await
            .map(drop)
    }
    /// Leases the newest stored login of hand-started session `id` (the server's login
    /// store is the one source of truth): the bytes and their stored version. A refusal
    /// carries the server's reason (`codex_login_stale: ...`), never login bytes.
    pub async fn session_login(&self, id: uuid::Uuid) -> Result<(Zeroizing<Vec<u8>>, i64)> {
        let path = format!("/v1/worker/manual-agents/{id}/login");
        let response = self
            .send(&path, "application/octet-stream", Vec::new())
            .await?;
        let status = response.status();
        let version = response.headers().get("aq-material-version");
        let version = version.and_then(|v| v.to_str().ok()?.parse().ok());
        let bytes = Zeroizing::new(response.bytes().await?.to_vec());
        if !status.is_success() {
            let reason = serde_json::from_slice::<aq_protocol::ApiError>(&bytes);
            let reason = reason.map_or_else(|_| status.to_string(), |e| e.message);
            bail!("{}", reason.chars().take(256).collect::<String>());
        }
        ensure!(bytes.len() <= 65536, "session login size");
        Ok((bytes, version.context("session login version")?))
    }
    /// Writes session `id`'s refreshed login back as version `base_version + 1`.
    /// `Ok((true, v))`: stored as (or already) version `v`; `Ok((false, v))`: a newer
    /// version `v` won and ours is discarded.
    pub async fn session_login_refresh(
        &self,
        id: uuid::Uuid,
        base_version: i64,
        login: &[u8],
    ) -> Result<(bool, i64)> {
        let path =
            format!("/v1/worker/manual-agents/{id}/login/refresh?base_version={base_version}");
        let response = self
            .send(&path, "application/octet-stream", login.to_vec())
            .await?;
        let status = response.status().as_u16();
        let outcome: serde_json::Value =
            serde_json::from_slice(&response.bytes().await?).unwrap_or_default();
        match (
            status,
            outcome["accepted"].as_bool(),
            outcome["version"].as_i64(),
        ) {
            (200, Some(true), Some(version)) => Ok((true, version)),
            (409, Some(false), Some(version)) => Ok((false, version)),
            _ => bail!("session login write-back refused (status {status})"),
        }
    }
    /// Every request: bearer, Access headers when set, JSON. A non-2xx answer becomes a
    /// `LinkError` carrying the status and the server's `error` code, never the request.
    async fn post<B: Serialize + Sync, T: DeserializeOwned>(
        &self,
        path: &str,
        body: &B,
    ) -> Result<T> {
        let response = self
            .send(path, "application/json", serde_json::to_vec(body)?)
            .await?;
        let status = response.status();
        let bytes = response
            .bytes()
            .await
            .map_err(|e| anyhow::anyhow!("read {path} reply: {}", e.without_url()))?;
        if !status.is_success() {
            let code = serde_json::from_slice::<aq_protocol::ApiError>(&bytes)
                .ok()
                .map(|e| e.error);
            return Err(LinkError {
                status: status.as_u16(),
                code,
            }
            .into());
        }
        let bytes = if bytes.is_empty() {
            &b"null"[..]
        } else {
            &bytes[..]
        };
        serde_json::from_slice(bytes).with_context(|| format!("decode {path} reply"))
    }
}
impl ServerLink {
    /// One POST under the node credential (and Access headers when set).
    async fn send(
        &self,
        path: &str,
        content_type: &'static str,
        body: Vec<u8>,
    ) -> Result<reqwest::Response> {
        let mut bearer = header::HeaderValue::from_str(&format!("Bearer {}", &*self.credential))
            .map_err(|_| anyhow::anyhow!("invalid node credential"))?;
        bearer.set_sensitive(true);
        let mut request = self
            .http
            .post(self.origin.join(path)?)
            .header(header::AUTHORIZATION, bearer)
            .header(header::CONTENT_TYPE, content_type)
            .body(body);
        if let Some((id, secret)) = &self.access {
            let mut secret = header::HeaderValue::from_str(secret)
                .map_err(|_| anyhow::anyhow!("invalid Access secret"))?;
            secret.set_sensitive(true);
            request = request
                .header("cf-access-client-id", id)
                .header("cf-access-client-secret", secret);
        }
        let path = path.split('?').next().unwrap_or(path);
        request
            .send()
            .await
            .map_err(|e| anyhow::anyhow!("request to {path} failed: {}", e.without_url()))
    }
}
pub fn validate_control(reply: &ControlResponse) -> Result<()> {
    ensure!(
        matches!(
            reply.schema_version,
            1 | aq_protocol::NODE_SLOTS_SCHEMA_VERSION
        ) && reply.slots.is_none_or(|n| reply.schema_version
            == aq_protocol::NODE_SLOTS_SCHEMA_VERSION
            && n <= aq_protocol::MAX_NODE_SLOTS),
        "invalid node control response"
    );
    Ok(())
}
async fn negotiate_control<F, T>(version: u32, mut post: F) -> Result<(ControlResponse, u32)>
where
    F: FnMut(u32) -> T,
    T: std::future::Future<Output = Result<ControlResponse>>,
{
    let (reply, version) = match post(version).await {
        Err(e)
            if version == aq_protocol::NODE_SLOTS_SCHEMA_VERSION
                && e.downcast_ref::<LinkError>().is_some_and(|e| {
                    e.status == 400 && e.code.as_deref() == Some("bad_request")
                }) =>
        {
            (post(1).await?, 1)
        }
        other => (other?, version),
    };
    validate_control(&reply)?;
    ensure!(
        reply.schema_version == version,
        "control response schema differs from request"
    );
    Ok((reply, version))
}
/// The aq-worker-ctl machine-config rule: lower-case, every byte outside [a-z0-9-] becomes '-',
/// cut to 63. None when the result is not a valid key (for example it starts with '-').
pub fn default_machine_key(hostname: &str) -> Option<String> {
    let key: String = hostname
        .to_lowercase()
        .bytes()
        .map(|b| {
            if matches!(b, b'a'..=b'z' | b'0'..=b'9' | b'-') {
                b as char
            } else {
                '-'
            }
        })
        .take(63)
        .collect();
    valid_machine_key(&key).then_some(key)
}

#[cfg(test)]
mod tests {
    use super::*;
    use axum::{Json, Router, http::HeaderMap, routing::post};
    use std::sync::{Arc, Mutex};

    fn control_reply(version: u32, slots: Option<u32>) -> ControlResponse {
        ControlResponse {
            schema_version: version,
            slots,
            machine_key: "desk".into(),
            desired: aq_protocol::DesiredState::Running,
            generation: 1,
            handoff: vec![],
            qualification: None,
        }
    }
    #[tokio::test]
    async fn old_server_falls_back_once_and_missing_count_means_one() {
        let sent = std::sync::Mutex::new(vec![]);
        let (reply, version) = negotiate_control(2, |schema| {
            sent.lock().unwrap().push(schema);
            async move {
                if schema == 2 {
                    Err(LinkError {
                        status: 400,
                        code: Some("bad_request".into()),
                    }
                    .into())
                } else {
                    Ok(control_reply(1, None))
                }
            }
        })
        .await
        .unwrap();
        assert_eq!(*sent.lock().unwrap(), vec![2, 1]);
        assert_eq!((version, reply.node_slots()), (1, 1));
        let (_, version) = negotiate_control(version, |schema| {
            assert_eq!(schema, 1);
            async { Ok(control_reply(1, None)) }
        })
        .await
        .unwrap();
        assert_eq!(version, 1);
        assert_eq!(control_reply(2, None).node_slots(), 1);
    }
    #[tokio::test]
    async fn revoked_credentials_and_edges_never_trigger_a_protocol_fallback() {
        for status in [401, 403, 500] {
            let mut sends = 0;
            assert!(
                negotiate_control(2, |_| {
                    sends += 1;
                    async move {
                        Err(LinkError {
                            status,
                            code: Some("unauthorized".into()),
                        }
                        .into())
                    }
                })
                .await
                .is_err()
            );
            assert_eq!(sends, 1);
        }
        assert!(validate_control(&control_reply(1, Some(3))).is_err());
        assert!(validate_control(&control_reply(2, Some(1025))).is_err());
    }
    #[test]
    fn refuses_plain_http_off_loopback() {
        assert!(ServerLink::new("http://10.0.0.5:8081", "c", None).is_err());
        assert!(ServerLink::new("http://127.0.0.1:28081", "c", None).is_ok());
        assert!(ServerLink::new("http://[::1]:28081", "c", None).is_ok());
        assert!(ServerLink::new("https://aq.example.com", "c", None).is_ok());
        assert!(ServerLink::new("https://u:p@aq.example.com", "c", None).is_err());
        assert!(ServerLink::new("https://aq.example.com/x", "c", None).is_err());
    }
    #[tokio::test]
    async fn sends_bearer_and_access_headers() {
        let seen = Arc::new(Mutex::new(Vec::<(String, String, String, String)>::new()));
        let log = seen.clone();
        let handler = move |name: &'static str| {
            let log = log.clone();
            post(move |h: HeaderMap, Json(_): Json<serde_json::Value>| {
                let log = log.clone();
                async move {
                    let get = |k: &str| {
                        h.get(k)
                            .map(|v| v.to_str().unwrap().to_owned())
                            .unwrap_or_default()
                    };
                    log.lock().unwrap().push((
                        name.into(),
                        get("authorization"),
                        get("cf-access-client-id"),
                        get("cf-access-client-secret"),
                    ));
                    Json(serde_json::json!(null))
                }
            })
        };
        let app = Router::new()
            .route("/v1/worker/handoffs", handler("handoffs"))
            .route("/v1/worker/machine", handler("machine"));
        let listener = tokio::net::TcpListener::bind("127.0.0.1:0").await.unwrap();
        let origin = format!("http://{}", listener.local_addr().unwrap());
        let server = tokio::spawn(async move { axum::serve(listener, app).await.unwrap() });
        let link = ServerLink::new(&origin, "node-cred", Some(("cid", "csecret"))).unwrap();
        link.handoff(&HandoffNotice {
            schema_version: 1,
            attempt_id: uuid::Uuid::nil(),
            reason: aq_protocol::HandoffReason::Restart,
        })
        .await
        .unwrap();
        link.machine_report(&serde_json::json!({"a": 1}))
            .await
            .unwrap();
        server.abort();
        let seen = seen.lock().unwrap();
        assert_eq!(
            seen.iter().map(|s| s.0.as_str()).collect::<Vec<_>>(),
            ["handoffs", "machine"]
        );
        for s in seen.iter() {
            assert_eq!(
                (s.1.as_str(), s.2.as_str(), s.3.as_str()),
                ("Bearer node-cred", "cid", "csecret")
            );
        }
    }
    #[tokio::test]
    async fn error_carries_status_not_secrets() {
        let app = Router::new().route(
            "/v1/worker/control",
            post(|| async {
                (
                    axum::http::StatusCode::UNAUTHORIZED,
                    Json(serde_json::json!({"error": "unauthorized", "message": "no"})),
                )
            }),
        );
        let listener = tokio::net::TcpListener::bind("127.0.0.1:0").await.unwrap();
        let origin = format!("http://{}", listener.local_addr().unwrap());
        let server = tokio::spawn(async move { axum::serve(listener, app).await.unwrap() });
        let link = ServerLink::new(&origin, "very-secret-credential", None).unwrap();
        let error = link.control().await.unwrap_err();
        server.abort();
        let e = error.downcast_ref::<LinkError>().unwrap();
        assert_eq!((e.status, e.code.as_deref()), (401, Some("unauthorized")));
        assert!(!format!("{error:#}").contains("very-secret"));
    }
    /// Review M5: only AQ's own 401/403 is a revoke; an edge's redirect or bare 403 is not.
    #[tokio::test]
    async fn edge_refusals_are_not_revocations() {
        use axum::http::{StatusCode, header::LOCATION};
        let app = Router::new()
            .route(
                "/v1/worker/control",
                post(|| async {
                    (
                        StatusCode::FOUND,
                        [(LOCATION, "https://team.cloudflareaccess.com/login")],
                        "",
                    )
                }),
            )
            .route(
                "/v1/worker/handoffs",
                post(|| async {
                    (
                        StatusCode::FORBIDDEN,
                        "<html>Forbidden. You don't have permission</html>",
                    )
                }),
            )
            .route(
                "/v1/worker/machine",
                post(|| async {
                    (
                        StatusCode::FORBIDDEN,
                        Json(serde_json::json!({"error": "revoked", "message": "no"})),
                    )
                }),
            );
        let listener = tokio::net::TcpListener::bind("127.0.0.1:0").await.unwrap();
        let origin = format!("http://{}", listener.local_addr().unwrap());
        let server = tokio::spawn(async move { axum::serve(listener, app).await.unwrap() });
        let link = ServerLink::new(&origin, "c", None).unwrap();
        let notice = HandoffNotice {
            schema_version: 1,
            attempt_id: uuid::Uuid::nil(),
            reason: aq_protocol::HandoffReason::Restart,
        };
        let errors = [
            link.control().await.map(drop).unwrap_err(),
            link.handoff(&notice).await.unwrap_err(),
            link.machine_report(&serde_json::json!({}))
                .await
                .unwrap_err(),
        ];
        server.abort();
        let kinds: Vec<_> = (errors.iter())
            .map(|e| e.downcast_ref::<LinkError>().unwrap())
            .map(|l| (l.status, l.revoked(), l.edge_refused()))
            .collect();
        assert_eq!(
            kinds,
            [(302, false, true), (403, false, true), (403, true, false)]
        );
    }
    #[test]
    fn default_machine_key_follows_the_ctl_rule() {
        assert_eq!(
            default_machine_key("DESKTOP-7Q").as_deref(),
            Some("desktop-7q")
        );
        assert_eq!(
            default_machine_key("my_box.local").as_deref(),
            Some("my-box-local")
        );
        assert_eq!(default_machine_key("-x"), None);
        assert_eq!(default_machine_key(&"a".repeat(80)).unwrap().len(), 63);
    }
}
