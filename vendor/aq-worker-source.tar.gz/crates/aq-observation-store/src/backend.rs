//! Private positional IO with a physical file cap and deterministic instrumentation.
use anyhow::{Result, ensure};
use redb::{BackendError, StorageBackend};
use serde::{Deserialize, Serialize};
use std::{
    fs::{File, Metadata},
    io,
    ops::Bound,
    os::{
        fd::{AsRawFd, FromRawFd},
        unix::fs::{FileExt, MetadataExt, OpenOptionsExt},
    },
    path::{Path, PathBuf},
    sync::{Arc, Mutex},
};
#[derive(Clone, Debug, Default, Serialize, Deserialize)]
pub struct IoStats {
    pub read_bytes: u64,
    pub written_bytes: u64,
    pub syncs: u64,
    pub resizes: u64,
    pub operations: u64,
    pub peak_file_bytes: u64,
}
#[derive(Clone, Copy, Debug)]
pub enum Action {
    Error,
    Exit,
}
#[derive(Clone, Copy, Debug)]
pub struct Fault {
    pub operation: u64,
    pub after: bool,
    pub action: Action,
}
#[derive(Debug, Default)]
struct Control {
    stats: IoStats,
    fault: Option<Fault>,
}
#[derive(Clone, Debug, Default)]
pub struct Monitor(Arc<Mutex<Control>>);
impl Monitor {
    pub fn reset(&self) {
        let mut c = self.0.lock().unwrap();
        c.stats = IoStats::default();
        c.fault = None;
    }
    pub fn fault(&self, fault: Fault) {
        self.0.lock().unwrap().fault = Some(fault);
    }
    pub fn stats(&self) -> IoStats {
        self.0.lock().unwrap().stats.clone()
    }
    pub(crate) fn boundary(&self, after: bool) -> io::Result<()> {
        let mut c = self.0.lock().unwrap();
        if !after {
            c.stats.operations += 1;
        }
        if let Some(f) = c
            .fault
            .filter(|f| (f.operation, f.after) == (c.stats.operations, after))
        {
            match f.action {
                Action::Error => return Err(io::Error::other("prototype injected IO fault")),
                Action::Exit => std::process::exit(77),
            }
        }
        Ok(())
    }
}
/// Held-fd and pathname identity must agree before every mutating IO.
#[derive(Debug)]
pub struct IdentityGuard {
    file: File,
    directory: File,
    root: Option<PathBuf>,
}
impl IdentityGuard {
    pub fn check(&self) -> io::Result<()> {
        let held = self.file.metadata()?;
        let directory = self.directory.metadata()?;
        let entry = database_entry(&self.directory)?;
        if !private_file(&held) || !matches_file(&entry, &held) {
            return Err(io::Error::other(
                "held database basename/inode changed; refuse unreachable writes",
            ));
        }
        if !private_directory(&directory, held.uid()) || directory.nlink() == 0 {
            return Err(io::Error::other("held private directory changed"));
        }
        if let Some(root) = &self.root {
            verify_root_identity(root, &directory)?;
        }
        Ok(())
    }
}
fn database_entry(directory: &File) -> io::Result<libc::stat> {
    let mut stat = std::mem::MaybeUninit::<libc::stat>::uninit();
    let result = unsafe {
        libc::fstatat(
            directory.as_raw_fd(),
            c"store.redb".as_ptr(),
            stat.as_mut_ptr(),
            libc::AT_SYMLINK_NOFOLLOW,
        )
    };
    if result != 0 {
        return Err(io::Error::last_os_error());
    }
    Ok(unsafe { stat.assume_init() })
}

fn private_file(file: &Metadata) -> bool {
    file.is_file()
        && file.nlink() == 1
        && file.uid() == unsafe { libc::geteuid() }
        && file.mode() & 0o077 == 0
}

// The basename and held descriptor must still refer to the same private file.
fn matches_file(entry: &libc::stat, held: &Metadata) -> bool {
    let same_inode = (entry.st_dev, entry.st_ino) == (held.dev(), held.ino());
    let is_private = entry.st_mode & 0o077 == 0 && entry.st_uid == held.uid();
    let regular_single_link = entry.st_mode & libc::S_IFMT == libc::S_IFREG && entry.st_nlink == 1;
    same_inode && is_private && regular_single_link
}
fn private_directory(directory: &Metadata, uid: u32) -> bool {
    directory.is_dir() && directory.uid() == uid && directory.mode() & 0o077 == 0
}
fn verify_root_identity(root: &Path, directory: &Metadata) -> io::Result<()> {
    let named = std::fs::symlink_metadata(root)?;
    let same_directory =
        named.is_dir() && (named.dev(), named.ino()) == (directory.dev(), directory.ino());
    if !same_directory || std::fs::canonicalize(root)? != root {
        return Err(io::Error::other("private root basename/inode changed"));
    }
    Ok(())
}
#[derive(Debug)]
pub struct CappedFile {
    file: File,
    guard: Arc<IdentityGuard>,
    limit: u64,
    monitor: Monitor,
}
impl CappedFile {
    pub fn open(directory: &File, create: bool, limit: u64, monitor: Monitor) -> Result<Self> {
        let directory_meta = directory.metadata()?;
        ensure!(
            private_directory(&directory_meta, unsafe { libc::geteuid() }),
            "private backend directory required"
        );
        let name = c"store.redb";
        let flags = libc::O_RDWR
            | libc::O_NOFOLLOW
            | libc::O_NONBLOCK
            | libc::O_CLOEXEC
            | if create {
                libc::O_CREAT | libc::O_EXCL
            } else {
                0
            };
        let fd = unsafe { libc::openat(directory.as_raw_fd(), name.as_ptr(), flags, 0o600) };
        if fd < 0 {
            return Err(io::Error::last_os_error().into());
        }
        let file = unsafe { File::from_raw_fd(fd) };
        let m = file.metadata()?;
        ensure!(
            private_file(&m) && m.len() <= limit,
            "private capped database file refused"
        );
        // redb4.4.0's pinned format has a512-byte super-header. Its stable
        // fd/backend entry point is create-or-open, so reject a truncated
        // existing file before the engine can initialize an empty database.
        // https://github.com/cberner/redb/blob/7061f7e60d4573311c0636e161d417b93e9fd2b1/docs/design.md#database-super-header
        ensure!(
            create || m.len() >= 512,
            "existing database shorter than pinned512-byte super-header; preserve without initialization"
        );
        let guard = Arc::new(IdentityGuard {
            file: file.try_clone()?,
            directory: directory.try_clone()?,
            root: None,
        });
        guard.check()?;
        Ok(Self {
            file,
            guard,
            limit,
            monitor,
        })
    }
    pub fn bind_root(mut self, root: &Path) -> Result<Self> {
        Arc::get_mut(&mut self.guard)
            .expect("unshared backend")
            .root = Some(root.into());
        self.guard.check()?;
        Ok(self)
    }
    pub fn identity_guard(&self) -> Arc<IdentityGuard> {
        self.guard.clone()
    }
    fn end(&self, offset: u64, len: usize) -> io::Result<u64> {
        let end = offset
            .checked_add(len as u64)
            .ok_or_else(|| io::Error::other("offset overflow"))?;
        if end > self.limit {
            return Err(io::Error::other("physical database cap"));
        }
        Ok(end)
    }
}
fn whole(start: Bound<u64>, end: Bound<u64>) -> bool {
    matches!(start, Bound::Unbounded | Bound::Included(0)) && matches!(end, Bound::Unbounded)
}
impl StorageBackend for CappedFile {
    fn len(&self) -> io::Result<u64> {
        Ok(self.file.metadata()?.len())
    }
    fn read(&self, offset: u64, out: &mut [u8]) -> io::Result<()> {
        self.end(offset, out.len())?;
        self.file.read_exact_at(out, offset)?;
        self.monitor.0.lock().unwrap().stats.read_bytes += out.len() as u64;
        Ok(())
    }
    fn set_len(&self, len: u64) -> io::Result<()> {
        if len > self.limit {
            return Err(io::Error::other("physical database cap"));
        }
        self.guard.check()?;
        self.monitor.boundary(false)?;
        self.file.set_len(len)?;
        {
            let mut c = self.monitor.0.lock().unwrap();
            c.stats.resizes += 1;
            c.stats.peak_file_bytes = c.stats.peak_file_bytes.max(len);
        }
        self.monitor.boundary(true)
    }
    fn write(&self, offset: u64, data: &[u8]) -> io::Result<()> {
        let end = self.end(offset, data.len())?;
        self.guard.check()?;
        self.monitor.boundary(false)?;
        self.file.write_all_at(data, offset)?;
        {
            let mut c = self.monitor.0.lock().unwrap();
            c.stats.written_bytes += data.len() as u64;
            c.stats.peak_file_bytes = c.stats.peak_file_bytes.max(end);
        }
        self.monitor.boundary(true)
    }
    fn sync_data(&self) -> io::Result<()> {
        self.guard.check()?;
        self.monitor.boundary(false)?;
        self.file.sync_all()?;
        self.monitor.0.lock().unwrap().stats.syncs += 1;
        self.monitor.boundary(true)
    }
    fn try_lock_range(
        &self,
        start: Bound<u64>,
        end: Bound<u64>,
    ) -> std::result::Result<bool, BackendError> {
        if !whole(start, end) {
            return Err(BackendError::Unsupported);
        }
        match fs2::FileExt::try_lock_exclusive(&self.file) {
            Ok(()) => Ok(true),
            Err(e) if e.kind() == io::ErrorKind::WouldBlock => Ok(false),
            Err(e) => Err(e.into()),
        }
    }
    fn unlock_range(
        &self,
        start: Bound<u64>,
        end: Bound<u64>,
    ) -> std::result::Result<(), BackendError> {
        if !whole(start, end) {
            return Err(BackendError::Unsupported);
        }
        fs2::FileExt::unlock(&self.file).map_err(Into::into)
    }
    fn close(&self) -> io::Result<()> {
        fs2::FileExt::unlock(&self.file)
    }
}
pub fn private_root(root: &Path, create: bool) -> Result<(File, File)> {
    ensure!(root.is_absolute(), "absolute root required");
    if create {
        use std::os::unix::fs::DirBuilderExt;
        std::fs::DirBuilder::new().mode(0o700).create(root)?;
        File::open(root.parent().unwrap())?.sync_all()?;
    }
    ensure!(
        std::fs::canonicalize(root)? == root,
        "canonical root required"
    );
    let directory = std::fs::OpenOptions::new()
        .read(true)
        .custom_flags(libc::O_DIRECTORY | libc::O_NOFOLLOW | libc::O_CLOEXEC)
        .open(root)?;
    let m = directory.metadata()?;
    ensure!(
        m.uid() == unsafe { libc::geteuid() } && m.mode() & 0o077 == 0,
        "private directory required"
    );
    for entry in std::fs::read_dir(root)? {
        ensure!(
            matches!(
                entry?.file_name().to_str(),
                Some("owner.lock" | "store.redb" | "store.format")
            ),
            "unknown member retained for recovery"
        );
    }
    if !create {
        verify_format(&directory)?;
    }
    let fd = unsafe {
        libc::openat(
            directory.as_raw_fd(),
            c"owner.lock".as_ptr(),
            libc::O_RDWR | libc::O_CREAT | libc::O_NOFOLLOW | libc::O_CLOEXEC | libc::O_NONBLOCK,
            0o600,
        )
    };
    if fd < 0 {
        return Err(io::Error::last_os_error().into());
    }
    let owner = unsafe { File::from_raw_fd(fd) };
    let m = owner.metadata()?;
    ensure!(private_file(&m), "private owner lock refused");
    fs2::FileExt::try_lock_exclusive(&owner)?;
    directory.sync_all()?;
    Ok((directory, owner))
}

// This immutable marker is checked before the engine is opened, so refusing an
// old/unknown application format cannot repair/rewrite its redb header first.
fn format_bytes() -> Vec<u8> {
    serde_json::to_vec(&serde_json::json!({"format":super::budget::FORMAT,"control_catalog":super::budget::catalog_digest()})).unwrap()
}
pub(super) fn write_format(directory: &File) -> Result<()> {
    use std::io::Write;
    let fd = unsafe {
        libc::openat(
            directory.as_raw_fd(),
            c"store.format".as_ptr(),
            libc::O_WRONLY | libc::O_CREAT | libc::O_EXCL | libc::O_NOFOLLOW | libc::O_CLOEXEC,
            0o600,
        )
    };
    ensure!(fd >= 0, "exclusive format marker create failed");
    let mut file = unsafe { File::from_raw_fd(fd) };
    file.write_all(&format_bytes())?;
    file.sync_all()?;
    directory.sync_all()?;
    Ok(())
}
fn verify_format(directory: &File) -> Result<()> {
    use std::io::Read;
    let fd = unsafe {
        libc::openat(
            directory.as_raw_fd(),
            c"store.format".as_ptr(),
            libc::O_RDONLY | libc::O_NONBLOCK | libc::O_NOFOLLOW | libc::O_CLOEXEC,
        )
    };
    ensure!(
        fd >= 0,
        "store format marker missing; no implicit migration or reseed"
    );
    let file = unsafe { File::from_raw_fd(fd) };
    let m = file.metadata()?;
    ensure!(
        private_file(&m) && m.len() <= 256,
        "private format marker refused"
    );
    let mut bytes = vec![];
    file.take(257).read_to_end(&mut bytes)?;
    ensure!(
        bytes == format_bytes(),
        "unknown store format/control catalog; preserve without engine open"
    );
    Ok(())
}
