//! Reading the final `result` event of a harness turn: the proven-success rule
//! and the bounded conclusion line.
use crate::claim::{blocked, claimed_changes, field, names_paths};

/// The last stream-json `result` event Claude printed, if any.
fn last_result(stream: &[u8]) -> Option<serde_json::Value> {
    stream
        .split(|b| *b == b'\n')
        .rev()
        .filter_map(|line| serde_json::from_slice::<serde_json::Value>(line).ok())
        .find(|v| v["type"] == "result")
}

/// The text of the last stream-json `result` event, if any.
pub fn final_text(stream: &[u8]) -> Option<String> {
    last_result(stream).and_then(|r| r["result"].as_str().map(str::to_owned))
}
/// MS1 review B1: a Claude exit 0 alone never proves the work was done
/// (Claude can end its turn with a question, a refusal or "couldn't find X").
/// The driver records success only when all of these hold; otherwise the
/// executor reports Failed and D3 sends the task to rework (a charged failure).
///
/// - the runner exited 0 (backend-observed);
/// - the last stream-json `result` event has `subtype == "success"` and
///   `is_error == false` (auth failures, max-turns, budget and errors set
///   `is_error`);
/// - the agent's final text contains its own `Changes:` line;
/// - it does not say `Outcome: blocked`;
/// - when its `Changes:` value names a path, changes were copied back (review
///   I-2: a consistency check between the claim and the evidence; a value that
///   names no path is no claim, R1-I1).
///
/// An empty change set is not a failure (owner decision 2026-11-13): a task
/// may be read-only, and its result is the agent's final message.
pub fn proven_success(
    stream: &[u8],
    rc: Option<i32>,
    changed: &[String],
) -> std::result::Result<(), &'static str> {
    if rc != Some(0) {
        return Err("runner exit not 0");
    }
    let result = last_result(stream).ok_or("no final result event")?;
    if result["subtype"] != "success" || result["is_error"] != false {
        return Err("final result is not a success");
    }
    let text = result["result"].as_str().ok_or("no final message")?;
    let claim = claimed_changes(text).ok_or("final message has no Changes: line")?;
    if blocked(text) {
        return Err("the agent reported Outcome: blocked");
    }
    if names_paths(claim) && changed.is_empty() {
        return Err("the agent reported changes, but none were copied back");
    }
    Ok(())
}

/// Bound of the conclusion line (the result report's label holds 512 bytes).
const CONCLUSION_BYTES: usize = 500;
const CLIPPED: &str = " [clipped]";
const CLIPPED_TO_COMMENT: &str =
    " [clipped; the full message is sent to the task comments when the channel accepts it]";

/// One-line, bounded conclusion (review I-1, R1-M2): the agent's `Outcome`
/// (first, so clipping never removes it), its own `Changes:` claim, the
/// copied-back files, the exit code, then its final message (without the Changes
/// and Outcome lines), folded and clipped with an explicit marker. `in_comment`:
/// a post of the whole final message to the task comments follows the claim
/// (R3-M1: it may still be refused, so the marker does not promise it).
pub fn conclusion(stream: &[u8], rc: Option<i32>, changed: &[String], in_comment: bool) -> String {
    conclusion_of("Claude", stream, rc, changed, in_comment)
}

/// `conclusion` for the named harness (`Claude exit 0`, `Codex exit 0`): `stream`
/// is in the stream-json shape (`aq_codex_mapper::docker_local::result_stream`
/// maps Codex's output to it).
pub fn conclusion_of(
    harness: &str,
    stream: &[u8],
    rc: Option<i32>,
    changed: &[String],
    in_comment: bool,
) -> String {
    let text = final_text(stream).unwrap_or_else(|| "no final message".into());
    // R2-M3: no control, bidi or invisible format characters reach the summary.
    let text: String = text
        .chars()
        .filter(|c| crate::visible(*c) || *c == '\n')
        .collect();
    let outcome = if blocked(&text) {
        "blocked"
    } else if proven_success(stream, rc, changed).is_ok() {
        "done"
    } else {
        "incomplete"
    };
    let claim = claimed_changes(&text)
        .filter(|c| !c.is_empty())
        .unwrap_or("unknown");
    let copied = copied_files(changed);
    let message = result_message(&text);
    let rc = rc.map_or("unknown".to_string(), |c| c.to_string());
    let line = format!(
        "Outcome: {outcome}; Changes: {claim}; Copied: {copied}; {harness} exit {rc}; Result: {message}"
    );
    bounded_line(&line, in_comment)
}

fn result_message(text: &str) -> String {
    let keep = |l: &&str| field(l, "changes").is_none() && field(l, "outcome").is_none();
    let message: Vec<&str> = text.lines().filter(keep).collect();
    let rest = text
        .lines()
        .rev()
        .find(|l| field(l, "changes").is_some())
        .and_then(|l| l.split_once(';').map(|(_, rest)| rest.trim()))
        .unwrap_or_default();
    let message = format!("{} {rest}", message.join(" "));
    let message = message.split_whitespace().collect::<Vec<_>>().join(" ");
    if message.is_empty() {
        "none".to_string()
    } else {
        message
    }
}

fn copied_files(changed: &[String]) -> String {
    match changed.join(",") {
        files if files.is_empty() => "none".to_string(),
        files if files.len() > 120 => format!("{} files", changed.len()),
        files => files,
    }
}

fn bounded_line(line: &str, in_comment: bool) -> String {
    let mut line = line.split_whitespace().collect::<Vec<_>>().join(" ");
    if line.len() > CONCLUSION_BYTES {
        let marker = if in_comment {
            CLIPPED_TO_COMMENT
        } else {
            CLIPPED
        };
        let mut cut = CONCLUSION_BYTES - marker.len();
        while !line.is_char_boundary(cut) {
            cut -= 1;
        }
        line.truncate(cut);
        line.push_str(marker);
    }
    line
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn success_requires_exit_zero_a_successful_result_and_a_changes_line() {
        let done = result(
            "success",
            false,
            "Did it.\nChanges: src/lib.rs; Checks: cargo test; Limits: none",
        );
        let files = vec!["src/lib.rs".to_string()];
        assert_eq!(proven_success(&done, Some(0), &files), Ok(()));
        // Each refusal case alone keeps the attempt failed.
        for rc in [Some(1), None] {
            assert_eq!(proven_success(&done, rc, &files), Err("runner exit not 0"));
        }
        assert_eq!(
            proven_success(b"{\"type\":\"assistant\"}\n", Some(0), &files),
            Err("no final result event")
        );
    }
    #[test]
    fn unsuccessful_result_events_refuse_success() {
        let files = ["src/lib.rs".to_string()];
        for (subtype, is_error) in [
            ("success", true),
            ("error_max_turns", true),
            ("error_during_execution", false),
        ] {
            assert_eq!(
                proven_success(&result(subtype, is_error, "Changes: x"), Some(0), &files),
                Err("final result is not a success"),
                "{subtype} {is_error}"
            );
        }
        // A clarifying question or refusal ends the turn without a Changes line.
        let question = result(
            "success",
            false,
            "Which file should I edit? I could not find src/lib.rs.",
        );
        assert_eq!(
            proven_success(&question, Some(0), &files),
            Err("final message has no Changes: line")
        );
        // A read-only task changes no file and still succeeds.
        let read_only = result(
            "success",
            false,
            "The build passes.\nChanges: none; Checks: cargo test passed; Limits: none",
        );
        assert_eq!(proven_success(&read_only, Some(0), &[]), Ok(()));
    }
    #[test]
    fn only_the_last_result_event_counts() {
        let files = ["src/lib.rs".to_string()];
        let done = result_of("Did it.\nChanges: src/lib.rs");
        // Only the LAST result event counts.
        let mut later = done;
        later.extend(result("error_during_execution", true, "Changes: none"));
        assert_eq!(
            proven_success(&later, Some(0), &files),
            Err("final result is not a success")
        );
    }

    fn result(subtype: &str, is_error: bool, text: &str) -> Vec<u8> {
        format!(
            "{{\"type\":\"system\"}}\n{}\n",
            serde_json::json!({"type":"result","subtype":subtype,"is_error":is_error,"result":text})
        )
        .into_bytes()
    }
    fn result_of(text: &str) -> Vec<u8> {
        result("success", false, text)
    }

    #[test]
    fn ending_on_a_pending_build_records_an_incomplete_result() {
        let pending = result_of("Waiting for the build to finish.");
        let changed = ["src/lib.rs".into()];
        assert!(proven_success(&pending, Some(0), &changed).is_err());
        assert!(conclusion(&pending, Some(0), &changed, false).starts_with("Outcome: incomplete;"));
    }

    /// The Claude line is unchanged; another harness names itself in the exit field.
    #[test]
    fn conclusion_names_the_harness_that_ran() {
        let stream = result_of("Done.\nChanges: a.rs; Checks: none; Limits: none");
        let changed = ["a.rs".to_string()];
        let claude = conclusion(&stream, Some(0), &changed, false);
        assert_eq!(
            claude,
            conclusion_of("Claude", &stream, Some(0), &changed, false)
        );
        let codex = conclusion_of("Codex", &stream, Some(0), &changed, false);
        let (prefix, suffix) = claude.split_once("; Claude exit 0; ").expect(&claude);
        assert_eq!(codex, format!("{prefix}; Codex exit 0; {suffix}"));
    }

    /// Review I-2: a claim of changes that did not arrive is refused; this is a
    /// consistency check, not a file-change requirement.
    #[test]
    fn claimed_changes_that_were_not_copied_back_fail() {
        let edits =
            result_of("Done.\nChanges: src/lib.rs, src/api.rs; Checks: cargo test; Limits: none");
        assert_eq!(
            proven_success(&edits, Some(0), &[]),
            Err("the agent reported changes, but none were copied back")
        );
        assert_eq!(
            proven_success(&edits, Some(0), &["src/lib.rs".into()]),
            Ok(())
        );
        // Review R1-I1: the same table as the claim parser, through proven_success.
        for (claims, value) in crate::claim::tests::cases() {
            let text = format!("Answer.\nChanges: {value}; Checks: none");
            let expected = if claims {
                Err("the agent reported changes, but none were copied back")
            } else {
                Ok(())
            };
            assert_eq!(
                proven_success(&result_of(&text), Some(0), &[]),
                expected,
                "{value:?}"
            );
        }
    }

    /// Owner ruling 4a: `Outcome: blocked` is a failure; a missing or unknown
    /// Outcome line is done, so existing agents keep working.
    #[test]
    fn an_outcome_blocked_line_fails_and_any_other_is_done() {
        for text in [
            "I could not find the config.\nOutcome: blocked\nChanges: none",
            "I could not find the config.\n**Outcome:** Blocked\nChanges: none",
            "I could not find the config.\noutcome: blocked.\nChanges: none",
        ] {
            assert_eq!(
                proven_success(&result_of(text), Some(0), &[]),
                Err("the agent reported Outcome: blocked"),
                "{text}"
            );
        }
        for text in [
            "Answer.\nOutcome: done\nChanges: none",
            "Answer.\nOutcome: maybe\nChanges: none",
            "Answer.\nChanges: none",
        ] {
            assert_eq!(
                proven_success(&result_of(text), Some(0), &[]),
                Ok(()),
                "{text}"
            );
        }
    }

    /// Review I-1, R1-M2: the recorded result is the agent's final message
    /// (bounded), led by its Outcome, its own Changes claim and the copied files.
    #[test]
    fn the_conclusion_keeps_the_final_message() {
        let cases = [
            (
                "CI fails because the lockfile is stale.\nRun cargo update.\nChanges: none; Checks: cargo test (passed); Limits: none",
                vec![],
                "Outcome: done; Changes: none; Copied: none; Claude exit 0; Result: CI fails because the lockfile is stale. Run cargo update. Checks: cargo test (passed); Limits: none",
            ),
            (
                "Added hello.\nOutcome: done\nChanges: src/lib.rs",
                vec!["src/lib.rs".into()],
                "Outcome: done; Changes: src/lib.rs; Copied: src/lib.rs; Claude exit 0; Result: Added hello.",
            ),
        ];
        for (message, changed, expected) in cases {
            let line = conclusion(&result_of(message), Some(0), &changed, false);
            assert_eq!(line, expected);
        }
    }
    #[test]
    fn long_unicode_messages_keep_the_outcome_and_clipping_marker() {
        let long = result_of(&format!(
            "{}\n**Outcome:** blocked\nChanges: none",
            "é".repeat(400)
        ));
        for (in_comment, marker) in [
            (false, " [clipped]"),
            (
                true,
                " [clipped; the full message is sent to the task comments when the channel accepts it]",
            ),
        ] {
            let clipped = conclusion(&long, None, &[], in_comment);
            let body = clipped
                .strip_prefix("Outcome: blocked; Changes: none;")
                .expect("clipping preserves the blocked status");
            assert!(body.ends_with(marker));
            assert!(clipped.len() <= CONCLUSION_BYTES);
        }
    }
    #[test]
    fn invisible_characters_are_excluded_from_summaries() {
        // R2-M3: no bidi or invisible format characters in the summary.
        let bidi = result_of("ab\u{202E}cd\u{2067}e\u{E0041}\u{2029}f\nChanges: none");
        assert!(conclusion(&bidi, Some(0), &[], false).ends_with("Result: abcdef"));
    }
    #[test]
    fn missing_results_explicitly_remain_incomplete() {
        let expected = "Outcome: incomplete; Changes: unknown; Copied: none; Claude exit unknown; Result: no final message";
        assert!(conclusion(b"", None, &[], false).starts_with(expected));
    }
}
