use super::*;
use aq_session_protocol::{ArtifactRef, BudgetBasis, Capability, Digest, SpendingBudget, Text};

pub(super) fn settings() -> (HarnessSettings, ModelSettings) {
    let artifact = ArtifactRef {
        id: Text::new("independently-selected-artifact").unwrap(),
        version: Text::new("1").unwrap(),
        digest: Digest::of(b"fixture metadata only"),
    };
    (
        HarnessSettings {
            harness: Text::new("codex").unwrap(),
            cli_version: Text::new(CODEX_CLI_VERSION).unwrap(),
            adapter: artifact.clone(),
            environment: artifact,
            required_capabilities: vec![Capability {
                id: Text::new("aq.harness.stop").unwrap(),
                version: 1,
            }],
        },
        ModelSettings {
            provider: Text::new("openai").unwrap(),
            model: Text::new("gpt-5.1-codex-mini").unwrap(),
            reasoning: Text::new("medium").unwrap(),
            max_output_tokens: 4096,
            spending_budget: None,
        },
    )
}
pub(super) fn selected<'a>(harness: &'a HarnessSettings, model: &'a ModelSettings) -> Settings<'a> {
    Settings {
        harness,
        model,
        terminal_input_enabled: false,
    }
}
#[test]
fn pure_recipe_does_not_require_remote_identity_or_existing_filesystem() {
    let (harness, model) = settings();
    let recipe = map(
        selected(&harness, &model),
        Paths {
            executable: Path::new("/aq-pure-mapper-fixture/executable"),
            workspace: Path::new("/aq-pure-mapper-fixture/workspace"),
            private_home: Path::new("/aq-pure-mapper-fixture/private-home"),
        },
    )
    .unwrap();
    assert_eq!(
        recipe.executable,
        Path::new("/aq-pure-mapper-fixture/executable")
    );
    assert_eq!(recipe.arguments.last().map(String::as_str), Some("-"));
    assert_eq!(recipe.environment.len(), 1);
    assert_eq!(
        recipe.environment["CODEX_HOME"],
        "/aq-pure-mapper-fixture/private-home"
    );
}

#[test]
fn relative_executable_is_refused() {
    let (harness, model) = settings();
    assert!(
        map(
            selected(&harness, &model),
            Paths {
                executable: Path::new("relative"),
                workspace: Path::new("/work"),
                private_home: Path::new("/home"),
            }
        )
        .is_err()
    );
}
#[test]
fn unsupported_settings_cannot_map_a_recipe() {
    let (harness, model) = settings();
    let mut input = selected(&harness, &model);
    input.terminal_input_enabled = true;
    assert!(validate_settings(input).is_err());
    for value in ["0.165.0", "0.167.0"] {
        let mut changed = harness.clone();
        changed.cli_version = Text::new(value).unwrap();
        assert!(validate_settings(selected(&changed, &model)).is_err());
    }
    for value in ["aq.unknown", "aq.budget.task-cost"] {
        let mut changed = harness.clone();
        changed.required_capabilities[0].id = Text::new(value).unwrap();
        assert!(validate_settings(selected(&changed, &model)).is_err());
    }
    let mut changed = harness.clone();
    changed.required_capabilities[0].version = 2;
    assert!(validate_settings(selected(&changed, &model)).is_err());
    let mut changed = model.clone();
    changed.provider = Text::new("other-provider").unwrap();
    assert!(validate_settings(selected(&harness, &changed)).is_err());
    changed = model.clone();
    changed.reasoning = Text::new("unsupported").unwrap();
    assert!(validate_settings(selected(&harness, &changed)).is_err());
    changed = model;
    changed.spending_budget = Some(SpendingBudget {
        currency: Text::new("USD").unwrap(),
        basis: BudgetBasis::TaskCumulativeEstimatedCost,
        limit_microunits: 1,
    });
    assert!(validate_settings(selected(&harness, &changed)).is_err());
}
/// `default` reasoning passes no effort override in either mode; the named
/// values pass exactly theirs; anything else is refused by name.
#[test]
fn reasoning_default_passes_no_effort_override_and_unknown_values_are_refused() {
    let (harness, model) = settings();
    let paths = || Paths {
        executable: Path::new("/installed/codex"),
        workspace: Path::new("/worktree"),
        private_home: Path::new("/private/home"),
    };
    let efforts = |recipe: &Recipe| -> Vec<String> {
        (recipe.arguments.iter())
            .filter(|a| a.starts_with("model_reasoning_effort"))
            .cloned()
            .collect()
    };
    let with = |value: &str| {
        let mut changed = model.clone();
        changed.reasoning = Text::new(value).unwrap();
        changed
    };
    for value in ["low", "medium", "high"] {
        let changed = with(value);
        validate_settings(selected(&harness, &changed)).unwrap();
        let recipe = map(selected(&harness, &changed), paths()).unwrap();
        assert_eq!(
            efforts(&recipe),
            [format!("model_reasoning_effort=\"{value}\"")]
        );
    }
    let default = with("default");
    validate_settings(selected(&harness, &default)).unwrap();
    let exec = map(selected(&harness, &default), paths()).unwrap();
    assert!(efforts(&exec).is_empty(), "{:?}", exec.arguments);
    let named = map(selected(&harness, &with("medium")), paths()).unwrap();
    assert_eq!(exec.arguments.len() + 2, named.arguments.len());
    let interactive = Settings {
        harness: &harness,
        model: &default,
        terminal_input_enabled: true,
    };
    validate_interactive_settings(interactive).unwrap();
    assert!(efforts(&map_interactive(interactive, paths()).unwrap()).is_empty());
    for value in ["", "Default", "off", "none", "minimal", "xhigh", "max"] {
        let Ok(text) = Text::new(value) else { continue };
        let mut changed = model.clone();
        changed.reasoning = text;
        let refused = validate_settings(selected(&harness, &changed)).unwrap_err();
        let expected = "expected default, low, medium or high";
        assert!(format!("{refused:#}").contains(expected), "{refused:#}");
        assert!(map(selected(&harness, &changed), paths()).is_err());
    }
}
#[test]
fn scoped_endpoint_accepts_only_nonzero_port_and_emits_metadata() {
    assert!(LoopbackResponsesEndpoint::new(0).is_err());
    let overrides = responses_overrides(LoopbackResponsesEndpoint::new(32123).unwrap());
    let config: toml::Value = toml::from_str(&overrides.join("\n")).unwrap();
    assert_eq!(
        config["openai_base_url"].as_str(),
        Some("http://127.0.0.1:32123/v1")
    );
    assert_eq!(
        config["features"]["responses_websockets"].as_bool(),
        Some(false)
    );
    assert_eq!(
        config["features"]["responses_websockets_v2"].as_bool(),
        Some(false)
    );
}

#[test]
fn exec_recipe_uses_json_and_reads_stdin() {
    let (harness, model) = settings();
    let old = map(selected(&harness, &model), fixture_paths()).unwrap();
    assert_eq!(old.arguments[1], "exec");
    assert_eq!(old.arguments.last().unwrap(), "-");
    assert!(old.arguments.iter().any(|a| a == "--json"));
    assert!(!old.environment.contains_key("HOME"));
}

#[test]
fn interactive_tui_uses_v1_model_prompt_mode() {
    let (harness, model) = settings();
    let interactive = Settings {
        harness: &harness,
        model: &model,
        terminal_input_enabled: true,
    };
    let tui = map_interactive(interactive, fixture_paths()).unwrap();
    for forbidden in ["exec", "--json", "--ephemeral", "-"] {
        assert!(!tui.arguments.iter().any(|a| a == forbidden));
    }
    assert_eq!(tui.arguments.last().unwrap(), "--");
    assert!(
        tui.arguments
            .windows(2)
            .any(|a| a[0] == "-m" && a[1] == model.model.as_str())
    );
    assert!(
        tui.arguments
            .iter()
            .any(|a| a == "cli_auth_credentials_store=\"file\"")
    );
    assert_eq!(
        tui.environment,
        BTreeMap::from([
            ("CODEX_HOME".into(), "/home/agent/.aq/codex".into()),
            ("HOME".into(), "/home/agent/.aq/codex".into()),
        ])
    );
}

#[test]
fn terminal_input_must_match_the_selected_mode() {
    let (harness, model) = settings();
    let interactive = Settings {
        harness: &harness,
        model: &model,
        terminal_input_enabled: true,
    };
    assert!(map(interactive, fixture_paths()).is_err());
    assert!(map_interactive(selected(&harness, &model), fixture_paths()).is_err());
}
#[test]
fn interactive_v1_composer_and_auth_dialog_rules_keep_no_escape_behavior() {
    for (view, expected) in [
        ("status\n› ", InteractiveViewport::Ready),
        (
            "› Sign in with ChatGPT",
            InteractiveViewport::AuthenticationRequired,
        ),
        ("Trust this folder?", InteractiveViewport::TrustDirectory),
        ("working...", InteractiveViewport::Waiting),
    ] {
        assert_eq!(classify_current_viewport(view), expected, "{view}");
    }
    assert_eq!(READY_DELAY_MS, 3000);
    assert_eq!(COMPOSER_CLEAR, &[0x15]);
    assert!(std::hint::black_box(SKIP_ESCAPE_BEFORE_ENTER));
}
fn with_confinement(harness: &HarnessSettings, id: &str) -> HarnessSettings {
    let mut changed = harness.clone();
    changed.required_capabilities.push(Capability {
        id: Text::new(id).unwrap(),
        version: 1,
    });
    changed
}
fn fixture_paths() -> Paths<'static> {
    Paths {
        executable: Path::new("/opt/aq/bin/codex"),
        workspace: Path::new("/work"),
        private_home: Path::new("/home/agent/.aq/codex"),
    }
}
#[test]
fn confinement_mode_selects_codex_sandbox_and_keeps_hardening() {
    let (harness, model) = settings();
    let native = with_confinement(&harness, aq_session_protocol::NATIVE_CONFINEMENT_CAPABILITY);
    let container = with_confinement(
        &harness,
        aq_session_protocol::CONTAINER_CONFINEMENT_CAPABILITY,
    );
    // The pre-existing entrypoint stays native-only: container is never a silent result.
    assert!(map(selected(&container, &model), fixture_paths()).is_err());
    assert!(map_container(selected(&native, &model), fixture_paths()).is_err());
    assert!(map_container(selected(&harness, &model), fixture_paths()).is_err());
    let native = map(selected(&native, &model), fixture_paths()).unwrap();
    let contained = map_container(selected(&container, &model), fixture_paths()).unwrap();
    let sandbox = |args: &[String]| {
        let i = args.iter().position(|a| a == "--sandbox").unwrap();
        assert_eq!(args.iter().filter(|a| *a == "--sandbox").count(), 1);
        args[i + 1].clone()
    };
    assert_eq!(sandbox(&native.arguments), "workspace-write");
    assert_eq!(sandbox(&contained.arguments), "danger-full-access");
    let mut expected = native.arguments.clone();
    let i = expected.iter().position(|a| a == "--sandbox").unwrap();
    expected[i + 1] = "danger-full-access".into();
    assert_eq!(contained.arguments, expected, "hardening flags unchanged");
    assert_eq!(contained.environment, native.environment);
}
#[test]
fn proxy_provider_routes_codex_through_runner_loopback_without_key() {
    let endpoint = LoopbackResponsesEndpoint::new(41234).unwrap();
    let overrides = proxy_provider_overrides(endpoint);
    for expected in [
        "model_provider=\"aq-runner-proxy\"",
        "model_providers.aq-runner-proxy.base_url=\"http://127.0.0.1:41234/v1\"",
        "model_providers.aq-runner-proxy.wire_api=\"responses\"",
        "model_providers.aq-runner-proxy.requires_openai_auth=true",
        "cli_auth_credentials_store=\"file\"",
        "features.api_key_model_discovery=false",
        "analytics.enabled=false",
    ] {
        assert!(
            overrides.iter().any(|o| o == expected),
            "missing {expected}"
        );
    }
    assert!(!overrides.iter().any(|o| o.starts_with("openai_base_url=")
        || o.contains("env_key")
        || o.contains("OPENAI_API_KEY")
        || o.contains("CODEX_API_KEY")
        || o.contains("bearer")));
}
