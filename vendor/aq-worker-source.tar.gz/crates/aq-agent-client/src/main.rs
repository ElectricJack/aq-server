use anyhow::{Context as _, Result, ensure};
use aq_agent_client::client::{AgentClient, Failure, MessageRoute, Outcome};
use clap::{Parser, Subcommand};
use serde_json::{Value, json};
use std::{io::Read, path::PathBuf};
use uuid::Uuid;

#[derive(Parser)]
#[command(
    name = "aq-agent",
    version,
    about = "Scoped AQ agent client; offline data grants no authority"
)]
struct Cli {
    #[arg(long)]
    state_dir: Option<PathBuf>,
    /// Optional assertion of the managed private credential binding. No token values.
    #[arg(long)]
    token_file: Option<PathBuf>,
    #[command(subcommand)]
    command: Command,
}
#[derive(Subcommand)]
enum Command {
    /// One bounded local completion claim; no Graph/task-completion authority.
    Result {
        #[command(subcommand)]
        command: ResultCommand,
    },
    Context {
        #[arg(long)]
        cached: bool,
    },
    Graph {
        #[command(subcommand)]
        command: Graph,
    },
    Operation {
        #[command(subcommand)]
        command: Operation,
    },
    /// Bound task/session mailbox reads, scoped sends and replies; no harness delivery.
    Message {
        #[command(subcommand)]
        command: Message,
    },
    /// Comments on your own task: record findings the owner sees in the task view.
    Comment {
        #[command(subcommand)]
        command: Comment,
    },
}
#[derive(Subcommand)]
enum Comment {
    /// Add a Markdown comment to this task. The body is BODY, --file, or stdin.
    /// After an uncertain outcome, rerun with the printed --operation-id and the
    /// same body: the server returns the original comment, never a duplicate.
    Add {
        /// The Markdown body (1..16384 bytes). Omit it, or pass "-", to read stdin.
        #[arg(conflicts_with = "file")]
        body: Option<String>,
        #[arg(long)]
        file: Option<PathBuf>,
        /// Retry an earlier add; a new UUID is generated when omitted.
        #[arg(long)]
        operation_id: Option<Uuid>,
        /// Print the validated server response JSON instead of text.
        #[arg(long)]
        json: bool,
    },
    /// List this task's comments, newest first, including earlier attempts'.
    List {
        #[arg(long, default_value_t = 20, value_parser = clap::value_parser!(u16).range(1..=100))]
        limit: u16,
        /// The next_cursor of a previous page, for older comments.
        #[arg(long)]
        cursor: Option<String>,
        #[arg(long)]
        json: bool,
    },
}
#[derive(Subcommand)]
enum Message {
    /// Read the bound session mailbox (or the task mailbox with --task).
    Inbox {
        #[arg(long)]
        task: bool,
        #[arg(long, default_value = "0")]
        after: String,
        #[arg(long, default_value_t = 32)]
        limit: u8,
        #[arg(long)]
        thread: Option<Uuid>,
    },
    /// Strict MessageSend JSON with a caller-chosen operation UUID.
    Send {
        #[arg(long)]
        request_file: Option<PathBuf>,
    },
    /// Strict MessageAck JSON for a message in the bound mailbox.
    Ack {
        #[arg(long)]
        request_file: Option<PathBuf>,
    },
    /// Strict MessageBodyRequest JSON for an omitted body, or every chunk of
    /// one message with --message-id (session mailbox, or task with --task).
    Body {
        #[arg(long, conflicts_with_all = ["message_id", "task"])]
        request_file: Option<PathBuf>,
        #[arg(long)]
        message_id: Option<Uuid>,
        #[arg(long, requires = "message_id")]
        task: bool,
    },
    /// Reply on the original thread to the original sender's mailbox. The body
    /// is read from --body-file or stdin; pass the same IDs to retry.
    Reply {
        #[arg(long)]
        message_id: Uuid,
        #[arg(long)]
        task: bool,
        #[arg(long)]
        body_file: Option<PathBuf>,
        #[arg(long)]
        operation_id: Option<Uuid>,
        #[arg(long)]
        reply_id: Option<Uuid>,
    },
}
#[derive(Subcommand)]
enum ResultCommand {
    /// Publish the original local intent, normally exit10 (pending).
    Submit {
        #[arg(long)]
        request_file: PathBuf,
    },
    /// Read local worker acknowledgment/recovery data; triggers no effects.
    Status,
}
#[derive(Subcommand)]
enum Operation {
    Get { operation_id: Uuid },
}
#[derive(Subcommand)]
enum Graph {
    Get {
        node_id: Uuid,
    },
    Revision {
        node_id: Uuid,
        revision: String,
    },
    History {
        node_id: Uuid,
        #[arg(long, default_value_t = 32)]
        limit: u32,
        #[arg(long)]
        cursor: Option<String>,
    },
    Search {
        text: String,
        #[arg(long)]
        kind_filter: Option<String>,
        #[arg(long, default_value_t = 32)]
        limit: u32,
        #[arg(long)]
        cursor: Option<String>,
    },
    Context {
        node_id: Uuid,
        #[arg(long, default_value_t = 1)]
        depth: u32,
        #[arg(long, default_value = "both")]
        direction: String,
        #[arg(long, default_value_t = 32)]
        max_nodes: u32,
        #[arg(long, default_value_t = 64)]
        max_edges: u32,
        #[arg(long, default_value_t = 262144)]
        max_bytes: u32,
    },
    Relationships {
        node_id: Uuid,
        #[arg(long, default_value = "both")]
        direction: String,
        #[arg(long = "edge-type", required = true)]
        edge_types: Vec<String>,
        #[arg(long, default_value_t = 32)]
        limit: u32,
        #[arg(long)]
        cursor: Option<String>,
    },
    /// Strict complete CommandRequest JSON. Its original operation UUID is durable before send.
    Command {
        #[arg(long)]
        request_file: Option<PathBuf>,
    },
}
fn read_input_bytes(path: Option<PathBuf>, limit: usize) -> Result<Vec<u8>> {
    let reader: Box<dyn Read> = match path {
        Some(path) => Box::new(std::fs::File::open(path)?),
        None => Box::new(std::io::stdin()),
    };
    let mut bytes = Vec::new();
    reader.take(limit as u64).read_to_end(&mut bytes)?;
    Ok(bytes)
}

fn input(path: Option<PathBuf>) -> Result<Value> {
    let bytes = read_input_bytes(path, aq_agent_client::contract::MAX_DOCUMENT_BYTES + 1)?;
    Ok(aq_agent_client::contract::parse(&bytes)?)
}

fn body_input(path: Option<PathBuf>) -> Result<String> {
    let bytes = read_input_bytes(path, aq_agent_client::mail::MAX_BODY_BYTES + 1)?;
    Ok(String::from_utf8(bytes)?)
}
/// The comment body from the argument, a file or stdin. A trailing newline
/// from a file or stdin is not part of the comment.
fn comment_body(body: Option<String>, file: Option<PathBuf>) -> Result<String> {
    if let Some(body) = body.filter(|b| b != "-") {
        return Ok(body);
    }
    let limit = aq_agent_client::comments::MAX_BODY_BYTES;
    let bytes = read_input_bytes(file, limit + 2)?;
    let text = String::from_utf8(bytes)?;
    Ok(text.trim_end_matches(['\n', '\r']).to_owned())
}
/// Text output for `comment` without --json. The value becomes a JSON string,
/// which `main` prints raw.
fn text(mut outcome: Outcome, json: bool, render: fn(&Value) -> String) -> Outcome {
    if !json {
        let line = if outcome.exit_code == 0 {
            render(&outcome.value)
        } else {
            aq_agent_client::comments::render_refusal(&outcome.value)
        };
        outcome.value = Value::String(line);
    }
    outcome
}
async fn run(cli: Cli) -> Result<Outcome> {
    let Cli {
        state_dir,
        token_file,
        command,
    } = cli;
    if let Command::Result { command } = command {
        return local_result(command, state_dir, token_file);
    }
    let state_dir = state_dir.context("Graph state-dir required")?;
    if let Some(file) = token_file {
        ensure!(
            file == state_dir.join("credential.json"),
            "token-file must match managed session binding"
        );
    }
    let mut client = AgentClient::open(&state_dir)?;
    match command {
        Command::Result { .. } => {
            unreachable!("local result dispatch completed before Graph client")
        }
        Command::Context { cached: true } => Ok(Outcome {
            value: client.cached_context()?,
            exit_code: 0,
        }),
        Command::Context { cached: false } => client.context().await,
        Command::Operation {
            command: Operation::Get { operation_id },
        } => client.operation(operation_id).await,
        Command::Comment {
            command:
                Comment::Add {
                    body,
                    file,
                    operation_id,
                    json,
                },
        } => {
            let body = comment_body(body, file)?;
            let operation_id = operation_id.unwrap_or_else(Uuid::new_v4);
            let outcome = client.comment_add(operation_id, &body).await?;
            Ok(text(outcome, json, aq_agent_client::comments::render_added))
        }
        Command::Comment {
            command:
                Comment::List {
                    limit,
                    cursor,
                    json,
                },
        } => {
            let outcome = client.comment_list(cursor.as_deref(), Some(limit)).await?;
            Ok(text(outcome, json, aq_agent_client::comments::render_page))
        }
        Command::Message { command } => run_message(&mut client, command).await,
        Command::Graph { command } => run_graph(&mut client, command).await,
    }
}

fn local_result(
    command: ResultCommand,
    state_dir: Option<PathBuf>,
    token_file: Option<PathBuf>,
) -> Result<Outcome> {
    ensure!(
        token_file.is_none(),
        "local result channel accepts no Graph token assertion"
    );
    let root = state_dir
        .or_else(|| std::env::var_os(aq_agent_result_local::RESULT_DIR_ENV).map(PathBuf::from))
        .context("result runtime channel unavailable")?;
    let client = aq_agent_client::completion::ResultClient::open(&root)?;
    match command {
        ResultCommand::Submit { request_file } => {
            client.submit(aq_agent_client::completion::read_input(&request_file)?)
        }
        ResultCommand::Status => client.status(),
    }
}
async fn run_message(client: &mut AgentClient, command: Message) -> Result<Outcome> {
    match command {
        Message::Reply {
            message_id,
            task,
            body_file,
            operation_id,
            reply_id,
        } => {
            let body = body_input(body_file)?;
            let operation_id = operation_id.unwrap_or_else(Uuid::new_v4);
            let reply_id = reply_id.unwrap_or_else(Uuid::new_v4);
            client
                .reply(!task, message_id, body, operation_id, reply_id)
                .await
        }
        Message::Body {
            message_id: Some(message_id),
            task,
            ..
        } => client.body(!task, message_id).await,
        command => {
            let (route, request) = match command {
                Message::Inbox {
                    task,
                    after,
                    limit,
                    thread,
                } => (
                    MessageRoute::Inbox,
                    client.inbox_request(!task, &after, limit, thread),
                ),
                Message::Send { request_file } => (MessageRoute::Send, input(request_file)?),
                Message::Ack { request_file } => (MessageRoute::Ack, input(request_file)?),
                Message::Body { request_file, .. } => (MessageRoute::Body, input(request_file)?),
                Message::Reply { .. } => unreachable!("reply dispatched above"),
            };
            client.message(route, request).await
        }
    }
}

async fn run_graph(client: &mut AgentClient, command: Graph) -> Result<Outcome> {
    let query = match command {
        Graph::Get { node_id } => json!({"kind":"get","node_id":node_id}),
        Graph::Revision { node_id, revision } => {
            json!({"kind":"revision","node_id":node_id,"revision":revision})
        }
        Graph::History {
            node_id,
            limit,
            cursor,
        } => json!({"kind":"history","node_id":node_id,"limit":limit,"cursor":cursor}),
        Graph::Search {
            text,
            kind_filter,
            limit,
            cursor,
        } => {
            json!({"kind":"search","text":text,"kind_filter":kind_filter,"limit":limit,"cursor":cursor})
        }
        Graph::Context {
            node_id,
            depth,
            direction,
            max_nodes,
            max_edges,
            max_bytes,
        } => {
            json!({"kind":"context","node_id":node_id,"depth":depth,"direction":direction,"max_nodes":max_nodes,"max_edges":max_edges,"max_bytes":max_bytes})
        }
        Graph::Relationships {
            node_id,
            direction,
            edge_types,
            limit,
            cursor,
        } => {
            json!({"kind":"relationships","node_id":node_id,"direction":direction,"edge_types":edge_types,"limit":limit,"cursor":cursor})
        }
        Graph::Command { request_file } => return client.command(input(request_file)?).await,
    };
    client.query(query).await
}
#[tokio::main]
async fn main() -> std::process::ExitCode {
    let cli = Cli::parse();
    match run(cli).await {
        Ok(outcome) => print_outcome(outcome),
        Err(error) => print_error(error),
    }
}

fn print_outcome(outcome: Outcome) -> std::process::ExitCode {
    // Comment text output is a plain string; failures go to stderr.
    if let Value::String(text) = &outcome.value {
        if outcome.exit_code == 0 {
            println!("{text}");
        } else {
            eprintln!("{text}");
        }
    } else if outcome.exit_code == 14 || outcome.exit_code == 15 {
        eprintln!("{}", outcome.value);
    } else {
        println!("{}", outcome.value);
    }
    outcome.exit_code.into()
}

fn print_error(error: anyhow::Error) -> std::process::ExitCode {
    // Never print raw parser, filesystem, credential, URL or response errors.
    if let Some(failure) = error.downcast_ref::<Failure>() {
        eprintln!("{}", serde_json::to_string(failure).unwrap());
        match failure.code {
            "authentication_or_authority_refused" => 14,
            "invalid_comment_body" | "invalid_comment_page" => 15,
            _ => 13,
        }
        .into()
    } else {
        eprintln!(
            "{}",
            json!({"code":"invalid_contract_or_private_state","effect":"not_asserted","retryable":false})
        );
        15.into()
    }
}
