//! Fixed launch policy and label identity. Nothing in an offer or request can
//! widen the create body: limits come from the reservation, mounts only from
//! the per-attempt volume and operator-declared aliases.
use super::config::{CHANNEL_TARGET, DockerLocalConfig, WORK_TARGET};
use crate::backend::{
    BackendError, BackendKind, CreateRequest, InventoryEntry, Ownership, ResourceLimits,
    SandboxIdentity, SandboxState, TemplateDigest, UnconfirmedReason,
};
use serde_json::{Value, json};
use sha2::{Digest, Sha256};
use std::collections::BTreeMap;
use uuid::Uuid;

pub const LABEL_MANAGED_BY: &str = "aq.managed-by";
pub const MANAGED_BY: &str = "aq-worker";
pub const LABEL_BACKEND: &str = "aq.backend";
pub const BACKEND: &str = "docker-local";
pub const LABEL_NODE: &str = "aq.node";
pub const LABEL_BOOT: &str = "aq.boot";
pub const LABEL_ATTEMPT: &str = "aq.attempt";
pub const LABEL_DIGEST: &str = "aq.template-digest";
pub const LABEL_DEADLINE: &str = "aq.hard-deadline-ms";
pub const LABEL_REQUEST: &str = "aq.request-sha256";
/// SBX20 limit; written only when the reservation carries disk bytes, so
/// labels of pre-SBX20 requests are unchanged.
pub const LABEL_DISK_LIMIT: &str = "aq.disk-limit-bytes";

/// SBX20 per-attempt limit: reservation disk bytes, else the node default.
pub fn disk_limit_bytes(config: &DockerLocalConfig, request: &CreateRequest) -> u64 {
    request
        .resources
        .and_then(|resources| resources.disk_bytes)
        .unwrap_or(config.disk_limit_bytes)
}

/// Limit recorded at create; absent label means the node default.
pub fn disk_limit_from_labels(config: &DockerLocalConfig, labels: &Value) -> Option<u64> {
    match labels.get(LABEL_DISK_LIMIT) {
        None => Some(config.disk_limit_bytes),
        Some(value) => value.as_str()?.parse().ok().filter(|limit| *limit > 0),
    }
}

/// Work-volume create body; hard mode adds a size quota (XFS prjquota).
pub fn volume_body(
    config: &DockerLocalConfig,
    request: &CreateRequest,
    labels: &BTreeMap<String, String>,
) -> Value {
    let mut body = json!({
        "Name": volume_name(&request.name),
        "Driver": "local",
        "Labels": labels,
    });
    if config.hard_disk_limit {
        body["DriverOpts"] = json!({ "o": format!("size={}", disk_limit_bytes(config, request)) });
    }
    body
}

pub fn volume_name(name: &str) -> String {
    format!("{name}-work")
}

/// Hex sha256 of the canonical request encoding; binds a name to one request.
pub fn request_hash(request: &CreateRequest) -> String {
    let encoded = serde_json::to_vec(request).expect("CreateRequest serializes");
    Sha256::digest(&encoded)
        .iter()
        .map(|byte| format!("{byte:02x}"))
        .collect()
}

pub fn labels(request: &CreateRequest) -> BTreeMap<String, String> {
    let owner = &request.owner;
    let mut labels = BTreeMap::from([
        (LABEL_MANAGED_BY.into(), MANAGED_BY.into()),
        (LABEL_BACKEND.into(), BACKEND.into()),
        (LABEL_NODE.into(), owner.node_id.hyphenated().to_string()),
        (LABEL_BOOT.into(), owner.boot_id.hyphenated().to_string()),
        (
            LABEL_ATTEMPT.into(),
            owner.attempt_id.hyphenated().to_string(),
        ),
        (LABEL_DIGEST.into(), request.template_digest.as_str().into()),
        (LABEL_DEADLINE.into(), request.hard_deadline_ms.to_string()),
        (LABEL_REQUEST.into(), request_hash(request)),
    ]);
    if let Some(disk) = request.resources.and_then(|resources| resources.disk_bytes) {
        labels.insert(LABEL_DISK_LIMIT.into(), disk.to_string());
    }
    labels
}

/// Label filter selecting every sandbox this worker owns on `node`, any boot.
pub fn node_filter(node: Uuid) -> String {
    let filter = json!({
        "label": [
            format!("{LABEL_MANAGED_BY}={MANAGED_BY}"),
            format!("{LABEL_BACKEND}={BACKEND}"),
            format!("{LABEL_NODE}={}", node.hyphenated()),
        ]
    });
    encode(&filter.to_string())
}

/// The complete create body. Callers have already validated `request` against
/// the config: resources present, digest allowlisted, aliases declared.
pub fn create_body(
    config: &DockerLocalConfig,
    request: &CreateRequest,
    image: &str,
    resources: ResourceLimits,
) -> Value {
    let mut mounts = vec![json!({
        "Type": "volume",
        "Source": volume_name(&request.name),
        "Target": WORK_TARGET,
        "ReadOnly": false,
    })];
    for alias in &request.mount_aliases {
        let declared = &config.mount_aliases[alias];
        mounts.push(json!({
            "Type": "bind",
            "Source": declared.host_path,
            "Target": declared.target,
            "ReadOnly": declared.read_only,
        }));
    }
    if let (true, Some(root)) = (request.agent_channel, &config.channel_root) {
        mounts.push(json!({
            "Type": "bind",
            "Source": root.join(request.owner.attempt_id.hyphenated().to_string()),
            "Target": CHANNEL_TARGET,
            "ReadOnly": false,
        }));
    }
    if let Some((host, target)) = &config.transcript {
        mounts.push(json!({ "Type": "bind", "Source": host, "Target": target, "ReadOnly": false }));
    }
    for (project, path) in &config.readonly_projects {
        mounts.push(json!({
            "Type": "bind",
            "Source": path,
            "Target": aq_node_git::workspaces::sandbox_path(*project),
            "ReadOnly": true,
        }));
    }
    let mut body = json!({
        "Image": image,
        "Labels": labels(request),
        "Env": [],
        "WorkingDir": WORK_TARGET,
        "ExposedPorts": {},
        "AttachStdin": config.runner_tty,
        "OpenStdin": config.runner_tty,
        "Tty": config.runner_tty,
        "HostConfig": {
            "Privileged": false,
            "CapAdd": [],
            "CapDrop": ["ALL"],
            "Devices": [],
            "DeviceCgroupRules": [],
            "SecurityOpt": ["no-new-privileges"],
            "NanoCpus": u64::from(resources.cpu_millis) * 1_000_000,
            "Memory": resources.memory_bytes,
            "MemorySwap": resources.memory_bytes,
            "PidsLimit": resources.pids,
            "NetworkMode": "bridge",
            "PortBindings": {},
            "PublishAllPorts": false,
            "Binds": config.cache_binds,
            "Mounts": mounts,
            "IpcMode": "private",
            "RestartPolicy": { "Name": "no" },
            "AutoRemove": false,
        },
    });
    if request.postgres {
        use aq_sandbox_archive::task_postgres as postgres;
        body["HostConfig"]["Tmpfs"] = json!({ (postgres::ROOT): postgres::TMPFS });
    }
    if config.hard_disk_limit {
        body["HostConfig"]["StorageOpt"] =
            json!({ "size": disk_limit_bytes(config, request).to_string() });
    }
    if let Some(command) = &config.runner_command {
        body["Cmd"] = json!(command);
    }
    body
}

/// Maps a daemon container status to a backend state and process count.
pub fn container_state(status: &str, running: bool) -> (SandboxState, Option<u64>) {
    match (status, running) {
        ("created", false) => (SandboxState::Created, Some(0)),
        ("running", true) => (SandboxState::Running, None),
        ("exited" | "dead", false) => (SandboxState::Stopped, Some(0)),
        _ => (SandboxState::Unknown, None),
    }
}

/// Rebuilds an inventory entry from labels written at create. Missing,
/// malformed or foreign-managed labels are uncertainty, never absence.
pub fn entry_from_labels(
    name: &str,
    labels: &Value,
    state: SandboxState,
    running_processes: Option<u64>,
    disk_present: bool,
) -> Result<InventoryEntry, BackendError> {
    let unknown = BackendError::Uncertain(UnconfirmedReason::UnknownState);
    let label = |key: &str| {
        labels
            .get(key)
            .and_then(Value::as_str)
            .ok_or(unknown.clone())
    };
    let uuid = |key: &str| {
        label(key).and_then(|value| Uuid::parse_str(value).map_err(|_| unknown.clone()))
    };
    if label(LABEL_MANAGED_BY)? != MANAGED_BY || label(LABEL_BACKEND)? != BACKEND {
        return Err(unknown);
    }
    let owner = Ownership {
        node_id: uuid(LABEL_NODE)?,
        boot_id: uuid(LABEL_BOOT)?,
        attempt_id: uuid(LABEL_ATTEMPT)?,
    };
    let hash = label(LABEL_REQUEST)?;
    if name != owner.deterministic_name()
        || hash.len() != 64
        || !hash.bytes().all(|b| b.is_ascii_hexdigit())
    {
        return Err(unknown);
    }
    let template_digest =
        TemplateDigest::parse(label(LABEL_DIGEST)?).map_err(|_| unknown.clone())?;
    let hard_deadline_ms = label(LABEL_DEADLINE)?
        .parse()
        .map_err(|_| unknown.clone())?;
    Ok(InventoryEntry {
        sandbox: SandboxIdentity {
            kind: BackendKind::DockerLocal,
            backend_id: name.to_string(),
            owner,
        },
        name: name.to_string(),
        template_digest,
        hard_deadline_ms,
        state,
        running_processes,
        disk_present,
    })
}

/// True when `labels` carries every expected label with the expected value.
pub fn labels_match(labels: &Value, expected: &BTreeMap<String, String>) -> bool {
    expected
        .iter()
        .all(|(key, value)| labels.get(key).and_then(Value::as_str) == Some(value))
}

pub use super::transport::encode;
