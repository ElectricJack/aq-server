//! Native no-launch reservations and exact acceptance recovery. No grants or
//! process permits are reconstructed from disk. Run fsync on a bounded lane.
mod granted;
#[cfg(any(test, feature = "test-support"))]
mod pause;
use aq_worker_protocol::git_author::{AttemptOffer, GitAuthor};
#[cfg(test)]
pub(crate) use pause::Gate as NativePauseGate;
#[cfg(any(test, feature = "test-support"))]
pub use pause::WritePause;
mod input_origin;
mod inputs;
pub use input_origin::InputOrigin;
pub mod launch;
mod phase_execution;
mod phase_view;
pub mod preparation_refresh_v1;
mod refresh_execution;
mod refresh_prepared;
pub use refresh_execution::ReceivedPhaseExecution as ReceivedRefreshExecution;
pub use refresh_prepared::PhasePreparedIntent as RefreshPreparedIntent;
mod phase_prepared;
pub mod phase_terminal;
mod phase_terminal_budget;
pub mod refresh_terminal;
pub use phase_execution::ReceivedPhaseExecution;
pub mod preparation_v2;
mod prepared;
pub use phase_prepared::PhasePreparedIntent;
mod result;
mod source;
#[cfg(test)]
pub(crate) use result::salvage_history;
pub(crate) use result::terminal_stop as result_terminal_stop;
mod storage;
use super::http::{boot_ns, control::Preparation};
use anyhow::{Context, Result, ensure};
use aq_admission::{
    control::PreparationDelivery,
    startup::NativeOffer,
    transport::{Accept, NoLaunchReservation, TransportDocument, WorkerIdentity},
};
use aq_session_protocol::{
    ArtifactRef, Capability, Digest, ProfiledAcceptance, SessionIdentity, Validate,
};
pub use granted::ReceivedInitialGrant;
pub use inputs::{ArtifactDownload, MaterialDownload};
pub use prepared::PreparedIntent;
use serde::{Deserialize, Serialize};
pub use source::{SourceDownload, SourceRange};
use std::{
    collections::{BTreeMap, BTreeSet},
    path::Path,
};
use storage::Storage;
use uuid::Uuid;

pub const FORMAT: u32 = 12;
pub const MAX_BYTES: usize = 8 * 1024 * 1024;
const MAX_ATTEMPTS: usize = 64;
#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct Limits {
    pub slots: u32,
    pub memory_bytes: u64,
    pub cpu_millis: u64,
    pub disk_bytes: u64,
}
impl Limits {
    fn validate(&self) -> Result<()> {
        ensure!(
            (1..=64).contains(&self.slots)
                && self.memory_bytes > 0
                && self.cpu_millis > 0
                && self.disk_bytes > 0,
            "invalid native capacity"
        );
        Ok(())
    }
}
/// Both original installed runtime identity and its operator qualification must
/// survive configuration changes; neither is inferred from the offered harness.
#[derive(Clone, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct RuntimeIdentity {
    pub runtime: ArtifactRef,
    pub qualification: ArtifactRef,
}
#[derive(Clone, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct Reservation {
    pub offer: NativeOffer,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub git_author: Option<GitAuthor>,
    #[serde(default, skip_serializing_if = "std::ops::Not::not")]
    pub workspace_required: bool,
    pub runtime: RuntimeIdentity,
    pub reserved_at_ns: u64,
    pub deadline_ns: u64,
    pub disk_bytes: u64,
    pub reservation_id: Uuid,
    pub reservation_operation_id: Uuid,
    pub accept_operation_id: Uuid,
    pub guardian_id: Uuid,
    pub launch_id: Uuid,
}
#[derive(Clone, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct RecordedPreparation {
    pub delivery: PreparationDelivery,
    pub sent_ns: u64,
    pub received_ns: u64,
    pub deadline_ns: u64,
}
#[derive(Clone, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct Attempt {
    pub reservation: Reservation,
    pub acceptance: Option<Accept>,
    pub acceptance_digest: Option<Digest>,
    pub preparation: Option<RecordedPreparation>,
    pub downloads: BTreeMap<String, ArtifactDownload>,
    pub material_downloads: BTreeMap<Uuid, MaterialDownload>,
    pub source: Option<SourceDownload>,
    pub prepared: Option<PreparedIntent>,
    pub initial_grant: Option<ReceivedInitialGrant>,
    pub phase_acceptance: Option<preparation_v2::PhaseAcceptance>,
    pub phase_preparation: Option<preparation_v2::ReceivedPreparation>,
    pub phase_prepared: Option<PhasePreparedIntent>,
    pub phase_execution: Option<ReceivedPhaseExecution>,
    pub refresh_acceptance: Option<preparation_refresh_v1::PhaseAcceptance>,
    pub refresh_preparation: Option<preparation_refresh_v1::ReceivedPreparation>,
    pub refresh_prepared: Option<RefreshPreparedIntent>,
    pub refresh_execution: Option<ReceivedRefreshExecution>,
    pub native_host: Option<launch::NativeHostHistory>,
    pub result: Option<super::result::history::ResultHistory>,
}
#[derive(Clone, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct State {
    pub format: u32,
    pub identity: WorkerIdentity,
    pub kernel_boot_id: Uuid,
    pub revision: u64,
    pub attempts: BTreeMap<Uuid, Attempt>,
}
#[derive(Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
struct Snapshot {
    state: State,
    digest: Digest,
}
#[cfg(any(test, feature = "test-support"))]
#[derive(Clone, Copy)]
pub enum WriteFault {
    BeforeWrite,
    AfterFileSync,
    AfterRename,
    AfterDirectorySync,
}

/// Why recovery holds a slot instead of retrying (R1): a journal or history that retrying
/// cannot change. `.0` is the slot's holding reason (`journal_inconsistent`,
/// `journal_unreadable: <kind>`, ...); the error itself displays only its cause.
#[derive(Debug)]
pub struct RecoveryHold(pub &'static str, pub anyhow::Error);
impl std::fmt::Display for RecoveryHold {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        write!(f, "{:#}", self.1)
    }
}
impl std::error::Error for RecoveryHold {}
/// Runs `f` on a scoped thread with an 8 MiB stack (serde's derived visitors keep each journal
/// record's fields on the stack), so the calling worker's stack is not spent on it.
pub(crate) fn off_stack<T: Send>(f: impl FnOnce() -> Result<T> + Send) -> Result<T> {
    let thread = std::thread::Builder::new().name("aq-journal-decode".into());
    let panicked = |_| anyhow::anyhow!("journal decode thread panicked");
    std::thread::scope(|s| {
        thread
            .stack_size(8 << 20)
            .spawn_scoped(s, f)?
            .join()
            .map_err(panicked)?
    })
}
/// A `RecoveryHold` for `reason` unless `ok`.
pub(crate) fn hold_unless(ok: bool, reason: &'static str, why: &'static str) -> Result<()> {
    ok.then_some(())
        .ok_or_else(|| RecoveryHold(reason, anyhow::anyhow!(why)).into())
}
pub struct Journal {
    storage: Storage,
    state: State,
    limits: Limits,
    invocation: Uuid,
    kernel_boot_id: Uuid,
    poisoned: bool,
    #[cfg(any(test, feature = "test-support"))]
    fault: Option<WriteFault>,
    #[cfg(any(test, feature = "test-support"))]
    pause: Option<std::sync::Arc<pause::Gate>>,
}
fn canonical_bytes(value: &impl Serialize) -> Result<Vec<u8>> {
    let mut value = serde_json::to_value(value)?;
    value.sort_all_objects();
    Ok(serde_json::to_vec(&value)?)
}
pub(crate) fn canonical_digest(value: &impl Serialize) -> Result<Digest> {
    Ok(Digest::of(&canonical_bytes(value)?))
}
fn kernel_boot_id() -> Result<Uuid> {
    Ok(Uuid::parse_str(
        std::fs::read_to_string("/proc/sys/kernel/random/boot_id")?.trim(),
    )?)
}
fn same(a: &impl Serialize, b: &impl Serialize) -> Result<bool> {
    Ok(canonical_bytes(a)? == canonical_bytes(b)?)
}
fn validate_inline_receipts(offer: &NativeOffer) -> Result<()> {
    let artifacts = &offer.offered.artifacts;
    ensure!(
        artifacts.len() <= 126
            && artifacts
                .iter()
                .map(|a| a.artifact.digest.as_str())
                .collect::<BTreeSet<_>>()
                .len()
                == artifacts.len(),
        "native inline receipt set cannot satisfy Prepare"
    );
    Ok(())
}
impl Reservation {
    fn validate(
        &self,
        id: Uuid,
        owner: &WorkerIdentity,
        identities: &mut BTreeSet<Uuid>,
    ) -> Result<()> {
        self.offer.validate()?;
        self.git_author
            .as_ref()
            .map(GitAuthor::validate)
            .transpose()?;
        validate_inline_receipts(&self.offer)?;
        let offered = &self.offer.offered;
        for reference in [&self.runtime.runtime, &self.runtime.qualification] {
            reference.id.validate()?;
            reference.version.validate()?;
        }
        let binding = &offered.offer.binding;
        ensure!(
            id == binding.attempt_id
                && matches!(binding.session, SessionIdentity::Remote { node_id, boot_id, .. } if node_id == owner.node_id && boot_id == owner.boot_id),
            "native reservation owner"
        );
        ensure!(
            self.reserved_at_ns < self.deadline_ns
                && self.deadline_ns - self.reserved_at_ns
                    <= offered
                        .reservation_ttl_ms
                        .checked_mul(1_000_000)
                        .context("reservation duration overflow")?
                && self.disk_bytes > 0,
            "reservation deadline/disk"
        );
        ensure!(
            [
                self.reservation_id,
                self.reservation_operation_id,
                self.accept_operation_id,
                self.guardian_id,
                self.launch_id
            ]
            .iter()
            .all(|id| !id.is_nil() && identities.insert(*id)),
            "reservation identifiers"
        );
        Ok(())
    }
}
impl Attempt {
    fn validate_acceptance(&self, state: &State) -> Result<()> {
        let r = &self.reservation;
        if let Some(request) = &self.acceptance {
            ensure!(
                self.acceptance_digest.as_ref() == Some(&canonical_digest(request)?),
                "acceptance request digest"
            );
            TransportDocument::Accept(request.clone()).validate()?;
            request
                .acceptance
                .validate_against(&r.offer.offered.offer)?;
            ensure!(
                request.identity == state.identity
                    && (request.operation_id, request.guardian_id, request.launch_id)
                        == (r.accept_operation_id, r.guardian_id, r.launch_id)
                    && request.reservation.reservation_id == r.reservation_id
                    && request.reservation.reservation_operation_id == r.reservation_operation_id
                    && request.reservation.reservation_journal_digest == canonical_digest(r)?
                    && request.journal_revision < state.revision,
                "acceptance journal association"
            );
            ensure!(
                canonical_bytes(request)?.len() <= 65_536,
                "acceptance bytes bound"
            );
        }
        ensure!(
            self.acceptance.is_some() == self.acceptance_digest.is_some(),
            "orphan acceptance digest"
        );
        Ok(())
    }
    fn validate_preparation(&self) -> Result<()> {
        if let Some(record) = &self.preparation {
            let request = self
                .acceptance
                .as_ref()
                .context("preparation without acceptance")?;
            record
                .delivery
                .validate_for(request, record.delivery.delivery.nonce)?;
            let maximum = record.delivery.delivery.client_deadline_ns(
                record.sent_ns,
                record.received_ns,
                Some(self.reservation.deadline_ns),
            )?;
            ensure!(
                record.received_ns >= record.sent_ns
                    && record.received_ns < record.deadline_ns
                    && record.deadline_ns <= maximum,
                "preparation delivery clocks"
            );
        }
        Ok(())
    }
    fn new(reservation: Reservation) -> Self {
        Self {
            reservation,
            acceptance: None,
            acceptance_digest: None,
            preparation: None,
            downloads: BTreeMap::new(),
            material_downloads: BTreeMap::new(),
            source: None,
            prepared: None,
            initial_grant: None,
            phase_acceptance: None,
            phase_preparation: None,
            phase_prepared: None,
            phase_execution: None,
            refresh_acceptance: None,
            refresh_preparation: None,
            refresh_prepared: None,
            refresh_execution: None,
            native_host: None,
            result: None,
        }
    }
}
impl State {
    fn attempt_mut(&mut self, id: Uuid) -> Result<&mut Attempt> {
        self.attempts.get_mut(&id).context("unknown native attempt")
    }
    fn validate(&self, limits: &Limits) -> Result<()> {
        limits.validate()?;
        self.identity.validate()?;
        self.validate_header()?;
        let mut used = (0u32, 0u64, 0u64, 0u64);
        let mut identities = BTreeSet::new();
        let mut download_records = 0usize;
        let mut download_requests = 0usize;
        for (id, attempt) in &self.attempts {
            let r = &attempt.reservation;
            r.validate(*id, &self.identity, &mut identities)?;
            let resource = &r.offer.offered.offer.manifest.resources;
            used.0 = used.0.checked_add(1).context("slot overflow")?;
            used.1 = used
                .1
                .checked_add(resource.memory_bytes)
                .context("memory overflow")?;
            used.2 = used
                .2
                .checked_add(resource.cpu_millis)
                .context("cpu overflow")?;
            used.3 = used.3.checked_add(r.disk_bytes).context("disk overflow")?;
            self.validate_history(attempt, &mut identities)?;
            download_records += attempt.downloads.len() + attempt.material_downloads.len();
            download_requests += attempt
                .downloads
                .values()
                .map(|p| p.requests.len())
                .sum::<usize>()
                + attempt.material_downloads.len();
        }
        ensure!(
            download_records <= inputs::MAX_RECORDS && download_requests <= inputs::MAX_REQUESTS,
            "native input operation capacity"
        );
        ensure!(
            used.0 <= limits.slots
                && used.1 <= limits.memory_bytes
                && used.2 <= limits.cpu_millis
                && used.3 <= limits.disk_bytes,
            "native capacity exhausted"
        );
        self.validate_reserved_capacity()
    }
    fn validate_history(&self, attempt: &Attempt, identities: &mut BTreeSet<Uuid>) -> Result<()> {
        attempt.validate_acceptance(self)?;
        // Validate the one saved phase owner before checking any physical
        // input copies. InputOrigin equality relies on this shared check;
        // repeated proposal validation per input would be quadratic.
        preparation_v2::validate(attempt, &self.identity, self.revision)?;
        preparation_refresh_v1::validate(attempt, &self.identity, self.revision)?;
        ensure!(
            attempt.native_host.is_none()
                || attempt.phase_execution.is_some()
                || attempt.refresh_execution.is_some(),
            "host without actual phase execution"
        );
        attempt.validate_preparation()?;
        source::validate(attempt, self.revision, identities)?;
        prepared::validate(attempt, &self.identity, self.revision, identities)?;
        phase_prepared::validate(attempt, &self.identity, self.revision, identities)?;
        refresh_prepared::validate(attempt, &self.identity, self.revision, identities)?;
        granted::validate(attempt, self.revision)?;
        phase_execution::validate(attempt, self.kernel_boot_id, self.revision)?;
        refresh_execution::validate(attempt, self.kernel_boot_id, self.revision)?;
        launch::validate(attempt, self.revision, identities)?;
        result::validate(attempt, self, identities)?;
        phase_terminal::validate(attempt, self.revision)?;
        refresh_terminal::validate(attempt, self.revision)?;
        if let Some(h) = &attempt.native_host {
            let mut base = h.clone();
            base.terminal = None;
            base.refresh_terminal = None;
            ensure!(
                canonical_bytes(&base)?.len() <= phase_terminal_budget::BASE_HISTORY_MAX,
                "native base host history bound"
            );
        }
        ensure!(
            attempt
                .initial_grant
                .as_ref()
                .is_none_or(|g| g.kernel_boot_id == self.kernel_boot_id),
            "received grant kernel clock namespace"
        );
        inputs::validate(attempt, self, identities)?;
        Ok(())
    }
    fn validate_header(&self) -> Result<()> {
        ensure!(
            self.format == FORMAT
                && self.revision > 0
                && !self.kernel_boot_id.is_nil()
                && self.attempts.len() <= MAX_ATTEMPTS,
            "native journal version/shape"
        );
        Ok(())
    }
    fn validate_reserved_capacity(&self) -> Result<()> {
        // Do not add whole-state encoding work to non-host legacy/phase input paths.
        if self
            .attempts
            .values()
            .any(|a| a.native_host.is_some() || a.result.is_some())
        {
            let bytes = canonical_bytes(&Snapshot {
                state: self.clone(),
                digest: canonical_digest(self)?,
            })?
            .len();
            let result_reserve = result::remaining_reserve(self)?;
            ensure!(
                bytes
                    .checked_add(phase_terminal::remaining_reserve(self)?)
                    .and_then(|n| n.checked_add(result_reserve))
                    .is_some_and(|n| n <= MAX_BYTES),
                "native reserved host/outbox capacity"
            );
        }
        Ok(())
    }
}
impl Journal {
    /// Explicit initialization requires a brand new root; an existing empty or
    /// damaged root is never silently initialized as a node with free capacity.
    pub fn create(root: &Path, node_id: Uuid, limits: Limits) -> Result<Self> {
        Self::create_identity(
            root,
            WorkerIdentity {
                node_id,
                boot_id: Uuid::new_v4(),
            },
            limits,
        )
    }
    pub fn create_identity(root: &Path, identity: WorkerIdentity, limits: Limits) -> Result<Self> {
        identity.validate()?;
        limits.validate()?;
        let kernel_boot_id = kernel_boot_id()?;
        let state = State {
            format: FORMAT,
            identity: identity.clone(),
            kernel_boot_id,
            revision: 1,
            attempts: BTreeMap::new(),
        };
        let storage = Storage::open(root, true)?;
        let mut result = Self {
            storage,
            state,
            limits,
            invocation: identity.boot_id,
            kernel_boot_id,
            poisoned: false,
            #[cfg(any(test, feature = "test-support"))]
            fault: None,
            #[cfg(any(test, feature = "test-support"))]
            pause: None,
        };
        result.persist(result.state.clone())?;
        Ok(result)
    }
    /// Restart is inspection/stop-and-preserve only. Stored boot IDs and local
    /// clock values are history, never renewable authority in this invocation.
    pub fn open(root: &Path, node_id: Uuid, limits: Limits) -> Result<Self> {
        limits.validate()?;
        let storage = Storage::open(root, false)?;
        let names = storage.members()?;
        ensure!(
            names.iter().any(|n| n == "journal.json"),
            "native journal missing; capacity unknown"
        );
        let raw = storage.read(c"journal.json", MAX_BYTES)?;
        // R1: none of these can change on retry, so recovery holds the slot with the reason.
        let format = |e: serde_json::Error| RecoveryHold("journal_unreadable: format", e.into());
        let header: serde_json::Value = serde_json::from_slice(&raw).map_err(format)?;
        let known = header["state"]["format"].as_u64() == Some(FORMAT as u64);
        let why = "unsupported native journal format; preserve original evidence";
        hold_unless(known, "journal_unreadable: format", why)?;
        // R4: decoding the ~35 KiB attempts takes 1.7 MiB of stack in a dev build (0.45 optimized).
        let snapshot = off_stack(|| {
            let snapshot: Snapshot = serde_json::from_slice(&raw).map_err(format)?;
            let sealed = snapshot.digest == canonical_digest(&snapshot.state)?;
            let why = "native journal checksum";
            hold_unless(sealed, "journal_unreadable: checksum", why)?;
            let valid = snapshot.state.validate(&limits);
            valid.map_err(|e| RecoveryHold("journal_inconsistent", e))?;
            Ok(snapshot)
        })?;
        let ours = snapshot.state.identity.node_id == node_id;
        let why = "native journal belongs to another node";
        hold_unless(ours, "journal_unreadable: node", why)?;
        if names.iter().any(|n| n == "journal.pending") {
            // An unacknowledged pre-rename temp cannot precede a physical effect.
            // Validate the file safety, then keep the last published state. A
            // post-rename interruption already has the newer published state.
            storage.read(c"journal.pending", MAX_BYTES)?;
            storage.remove_pending()?;
        }
        Ok(Self {
            storage,
            state: snapshot.state,
            limits,
            invocation: Uuid::new_v4(),
            kernel_boot_id: kernel_boot_id()?,
            poisoned: false,
            #[cfg(any(test, feature = "test-support"))]
            fault: None,
            #[cfg(any(test, feature = "test-support"))]
            pause: None,
        })
    }
    fn attempt(&self, id: Uuid) -> Result<&Attempt> {
        self.state
            .attempts
            .get(&id)
            .context("unknown native attempt")
    }
    pub fn state(&self) -> &State {
        &self.state
    }
    /// Capacity for new polling is available only to this original live owner.
    /// Every retained record holds resources, including expired/unknown requests.
    pub fn available(&self) -> Result<Limits> {
        self.live()?;
        let mut free = self.limits.clone();
        for attempt in self.state.attempts.values() {
            let resource = &attempt.reservation.offer.offered.offer.manifest.resources;
            free.slots -= 1;
            free.memory_bytes -= resource.memory_bytes;
            free.cpu_millis -= resource.cpu_millis;
            free.disk_bytes -= attempt.reservation.disk_bytes;
        }
        Ok(free)
    }
    pub fn recovery_required(&self) -> bool {
        self.invocation != self.state.identity.boot_id
            || self.kernel_boot_id != self.state.kernel_boot_id
            || self.poisoned
    }
    fn live(&self) -> Result<u64> {
        self.storage.check_owner()?;
        ensure!(
            !self.recovery_required(),
            "native journal requires stop-and-preserve recovery"
        );
        boot_ns()
    }
    #[cfg(any(test, feature = "test-support"))]
    pub fn inject_fault(&mut self, fault: WriteFault) {
        self.fault = Some(fault);
    }
    #[cfg(any(test, feature = "test-support"))]
    pub fn pause_after_file_sync(&mut self, pause: &WritePause) {
        self.pause = Some(pause.gate.clone());
    }
    #[cfg(test)]
    pub(crate) fn set_pause_gate(&mut self, gate: std::sync::Arc<pause::Gate>) {
        self.pause = Some(gate);
    }
    fn persist(&mut self, state: State) -> Result<()> {
        ensure!(!self.poisoned, "native journal writer poisoned");
        state.validate(&self.limits)?;
        let bytes = canonical_bytes(&Snapshot {
            digest: canonical_digest(&state)?,
            state: state.clone(),
        })?;
        ensure!(bytes.len() <= MAX_BYTES, "native journal byte capacity");
        // From the first possible write onward, any error poisons this owner.
        self.poisoned = true;
        #[cfg(any(test, feature = "test-support"))]
        let fault = self.fault.take();
        #[cfg(any(test, feature = "test-support"))]
        if matches!(fault, Some(WriteFault::BeforeWrite)) {
            anyhow::bail!("injected before write");
        }
        self.storage.write_new(c"journal.pending", &bytes)?;
        #[cfg(any(test, feature = "test-support"))]
        if let Some(pause) = self.pause.take() {
            pause.wait()?;
        }
        #[cfg(any(test, feature = "test-support"))]
        if matches!(fault, Some(WriteFault::AfterFileSync)) {
            anyhow::bail!("injected after file fsync");
        }
        self.storage.publish()?;
        #[cfg(any(test, feature = "test-support"))]
        if matches!(fault, Some(WriteFault::AfterRename)) {
            anyhow::bail!("injected after rename");
        }
        self.storage.sync()?;
        #[cfg(any(test, feature = "test-support"))]
        if matches!(fault, Some(WriteFault::AfterDirectorySync)) {
            anyhow::bail!("injected after directory fsync");
        }
        self.state = state;
        self.poisoned = false;
        Ok(())
    }
    fn next(&self) -> Result<State> {
        let mut state = self.state.clone();
        state.revision = state
            .revision
            .checked_add(1)
            .context("native journal revision exhausted")?;
        Ok(state)
    }
    pub fn reserve(
        &mut self,
        offer: impl Into<AttemptOffer>,
        runtime: RuntimeIdentity,
        deadline_ns: u64,
        disk_bytes: u64,
    ) -> Result<Uuid> {
        self.reserve_with_workspaces(offer, runtime, deadline_ns, disk_bytes, false)
    }
    pub fn reserve_with_workspaces(
        &mut self,
        offer: impl Into<AttemptOffer>,
        runtime: RuntimeIdentity,
        deadline_ns: u64,
        disk_bytes: u64,
        workspace_required: bool,
    ) -> Result<Uuid> {
        let now = self.live()?;
        let AttemptOffer { offer, git_author } = offer.into();
        offer.validate()?;
        validate_inline_receipts(&offer)?;
        let id = offer.offered.offer.binding.attempt_id;
        ensure!(
            !self.state.attempts.contains_key(&id),
            "attempt already reserved"
        );
        let maximum = now
            .checked_add(
                offer
                    .offered
                    .reservation_ttl_ms
                    .checked_mul(1_000_000)
                    .context("reservation duration overflow")?,
            )
            .context("reservation deadline overflow")?;
        ensure!(
            now < deadline_ns && deadline_ns <= maximum,
            "expired/extended reservation"
        );
        let reservation = Reservation {
            offer,
            git_author,
            workspace_required,
            runtime,
            reserved_at_ns: now,
            deadline_ns,
            disk_bytes,
            reservation_id: Uuid::new_v4(),
            reservation_operation_id: Uuid::new_v4(),
            accept_operation_id: Uuid::new_v4(),
            guardian_id: Uuid::new_v4(),
            launch_id: Uuid::new_v4(),
        };
        let mut state = self.next()?;
        state.attempts.insert(id, Attempt::new(reservation));
        self.persist(state)?;
        Ok(id)
    }
    /// The Accept of reservation `r` (its original ids) with `remaining_ns` left on it.
    pub(crate) fn accept_for(
        &self,
        r: &Reservation,
        acceptance: ProfiledAcceptance,
        remaining_ns: u64,
    ) -> Result<Accept> {
        let reservation = NoLaunchReservation {
            reservation_id: r.reservation_id,
            reservation_operation_id: r.reservation_operation_id,
            reservation_journal_digest: canonical_digest(r)?,
        };
        Ok(Accept {
            schema_version: 1,
            operation_id: r.accept_operation_id,
            identity: self.state.identity.clone(),
            acceptance,
            reservation,
            guardian_id: r.guardian_id,
            launch_id: r.launch_id,
            journal_revision: self.state.revision,
            journal_digest: canonical_digest(&self.state)?,
            reservation_remaining_ms: remaining_ns / 1_000_000,
        })
    }
    /// Persist before sending. Retries return the original typed bytes/IDs and
    /// original remaining-time claim; physical sends use separate fresh nonces.
    pub fn begin_accept(
        &mut self,
        id: Uuid,
        advertised_capabilities: Vec<Capability>,
    ) -> Result<Accept> {
        let now = self.live()?;
        let attempt = self.attempt(id)?;
        let r = &attempt.reservation;
        ensure!(
            attempt.phase_acceptance.is_none() && attempt.refresh_acceptance.is_none(),
            "phase attempt cannot use legacy Accept"
        );
        ensure!(now < r.deadline_ns, "native reservation expired");
        let acceptance = ProfiledAcceptance {
            binding: r.offer.offered.offer.binding.clone(),
            advertised_capabilities,
        };
        acceptance.validate_against(&r.offer.offered.offer)?;
        if let Some(request) = &attempt.acceptance {
            ensure!(
                same(&request.acceptance, &acceptance)?,
                "changed acceptance retry"
            );
            return Ok(request.clone());
        }
        let request = self.accept_for(r, acceptance, r.deadline_ns - now)?;
        TransportDocument::Accept(request.clone()).validate()?;
        let mut state = self.next()?;
        let attempt = state.attempt_mut(id)?;
        attempt.acceptance_digest = Some(canonical_digest(&request)?);
        attempt.acceptance = Some(request.clone());
        self.persist(state)?;
        Ok(request)
    }
    pub fn record_preparation(&mut self, id: Uuid, observed: &Preparation) -> Result<()> {
        let now = self.live()?;
        let attempt = self.attempt(id)?;
        let request = attempt
            .acceptance
            .as_ref()
            .context("acceptance not durable")?;
        ensure!(
            attempt.phase_acceptance.is_none() && attempt.refresh_acceptance.is_none(),
            "phase attempt cannot use a legacy preparation plan"
        );
        observed
            .message()
            .validate_for(request, observed.message().delivery.nonce)?;
        let cap = attempt
            .preparation
            .as_ref()
            .map_or(attempt.reservation.deadline_ns, |p| p.deadline_ns);
        ensure!(
            now < observed.deadline_ns() && observed.deadline_ns() <= cap,
            "expired/extended preparation"
        );
        if let Some(previous) = &attempt.preparation {
            ensure!(
                same(&previous.delivery.original, &observed.message().original)?,
                "preparation replay changed"
            );
            observed
                .message()
                .versions
                .validate_after(&previous.delivery.versions)?;
        }
        let mut state = self.next()?;
        state.attempt_mut(id)?.preparation = Some(RecordedPreparation {
            delivery: observed.message().clone(),
            sent_ns: observed.sent_ns(),
            received_ns: observed.received_ns(),
            deadline_ns: observed.deadline_ns(),
        });
        self.persist(state)
    }
}
#[cfg(test)]
mod tests;
