//! Pure Gemini CLI recipe for unattended runs (I2; 0005 §8.3 rows in
//! `docs/implementation/I2.md`).
//!
//! The recipe is metadata only: argv, environment, working directory and the
//! system-settings bytes for the root-owned settings directory. It never
//! carries the
//! provider key:
//! - [`GeminiAuth::ApiKeyProxy`]: `GOOGLE_GEMINI_BASE_URL` points at the
//!   runner-held loopback proxy and `GEMINI_API_KEY` holds only that proxy's
//!   attempt-local capability (SBX7);
//! - [`GeminiAuth::Subscription`]: "Login with Google", whose refreshable
//!   `oauth_creds.json` C6b leases into `$GEMINI_CLI_HOME/.gemini` (SBX19).
//!
//! The CLI runs from the bundle's private Node, never the project's: the
//! executable is the bundle `node` and the first argument is the pinned
//! `gemini.js`. Settings go to the *system* settings file, which outranks the
//! user and workspace settings the agent's repository could supply. The CLI
//! honours that file only when it and every ancestor directory are owned by
//! uid 0 and not group/other writable, so it lives in its own directory
//! outside the agent home ([`GeminiPaths::system_settings_dir`]).
//!
//! Reasoning: the recipe passes no thinking setting, so the only accepted
//! `model.reasoning` is `default` (the CLI's own setting for the model). Any
//! other value is refused instead of being silently ignored.
//!
//! Only container confinement is offered: Gemini's own `--sandbox` needs
//! docker/podman (or macOS `sandbox-exec`), so there is no native mode.
use super::recipe::{self, RecipeSettings};
use crate::native::runner::sandbox::confinement::ConfinementMode;
use anyhow::{Context, Result, ensure};
use aq_session_protocol::{
    CONTAINER_CONFINEMENT_CAPABILITY, HarnessSettings, ModelSettings, NATIVE_CONFINEMENT_CAPABILITY,
};
use std::{
    collections::BTreeMap,
    path::{Path, PathBuf},
};

/// The pinned `@google/gemini-cli` npm version (contains commit 6814e00, the
/// recording format the observation reader targets).
pub const GEMINI_CLI_VERSION: &str = "0.67.0";
/// System settings file inside [`GeminiPaths::system_settings_dir`].
pub const SYSTEM_SETTINGS_FILE: &str = "system-settings.json";
/// Directory under `GEMINI_CLI_HOME` that holds the CLI's state.
pub const STATE_DIR: &str = ".gemini";
/// The file-stored Google login inside [`STATE_DIR`].
pub const OAUTH_FILE: &str = "oauth_creds.json";
/// Prefix of the proxy's attempt-local capability.
pub const CAPABILITY_PREFIX: &str = "aq-gemini-";
/// Variables that would select another credential, endpoint or settings
/// source. Only `GEMINI_API_KEY` (the proxy capability) and
/// `GOOGLE_GEMINI_BASE_URL` (the loopback proxy) are ever set, and only in
/// proxy mode.
pub const FORBIDDEN_ENVIRONMENT: &[&str] = &[
    "GEMINI_API_KEY",
    "GOOGLE_API_KEY",
    "GOOGLE_GEMINI_BASE_URL",
    "GOOGLE_VERTEX_BASE_URL",
    "GOOGLE_GENAI_USE_VERTEXAI",
    "GOOGLE_GENAI_USE_GCA",
    "GOOGLE_CLOUD_ACCESS_TOKEN",
    "GOOGLE_APPLICATION_CREDENTIALS",
    "GEMINI_CLI_USE_COMPUTE_ADC",
    "GEMINI_DEFAULT_AUTH_TYPE",
    "GEMINI_SANDBOX",
    "GEMINI_CLI_CUSTOM_HEADERS",
    "GEMINI_API_KEY_AUTH_MECHANISM",
    "CLOUD_SHELL",
    "ANTHROPIC_API_KEY",
    "OPENAI_API_KEY",
];

/// Lexical recipe paths, never evidence of installation or confinement.
#[derive(Clone, Copy)]
pub struct GeminiPaths<'a> {
    /// The bundle's private Node (`/opt/aq/node/bin/node`).
    pub node: &'a Path,
    /// The pinned CLI entry point (`/opt/aq/harnesses/gemini/bundle/gemini.js`).
    pub script: &'a Path,
    /// The process working directory; Gemini has no `--cwd` flag.
    pub workspace: &'a Path,
    /// Private agent home: both `HOME` and `GEMINI_CLI_HOME`.
    pub private_home: &'a Path,
    /// Fresh directory for [`SYSTEM_SETTINGS_FILE`], outside the home and the
    /// workspace (for example `/run/aq/gemini/<attempt>`). The runner creates
    /// it as uid 0 with mode 0755; its parent and every ancestor must already
    /// be root-owned, not group/other writable and traversable, or Gemini CLI
    /// 0.67.0 ignores the file.
    pub system_settings_dir: &'a Path,
}

/// How the CLI authenticates; neither variant carries the provider key.
#[derive(Clone, Copy)]
pub enum GeminiAuth<'a> {
    /// Runner-held loopback proxy origin (`http://127.0.0.1:<port>`) and its
    /// attempt-local capability.
    ApiKeyProxy {
        origin: &'a str,
        capability: &'a str,
    },
    /// File-stored Google login leased by C6b.
    Subscription,
}

pub struct GeminiRecipe {
    pub executable: PathBuf,
    pub arguments: Vec<String>,
    pub environment: BTreeMap<String, String>,
    pub working_directory: PathBuf,
    /// Bytes for `<system_settings_dir>/system-settings.json`.
    pub system_settings_json: Vec<u8>,
}

/// Crate-private: callers reach it through `GeminiAgentHome::install`, which
/// requires an `AuthorizedConfinement`. The prompt is delivered on stdin.
pub(crate) fn map(
    settings: RecipeSettings<'_>,
    paths: GeminiPaths<'_>,
    mode: ConfinementMode,
    auth: GeminiAuth<'_>,
) -> Result<GeminiRecipe> {
    let RecipeSettings { harness, model } = settings;
    validate_settings(harness, model, mode)?;
    let model_id = model.model.as_str();
    let GeminiPaths {
        node,
        script,
        workspace,
        private_home,
        system_settings_dir,
    } = paths;
    paths.validate()?;
    let home = private_home.to_str().context("Gemini home UTF8")?;
    let system_settings = system_settings_dir.join(SYSTEM_SETTINGS_FILE);
    let arguments = vec![
        script.to_str().context("Gemini script UTF8")?.to_owned(),
        // Headless; the prompt text arrives on stdin and is appended.
        "-p".into(),
        String::new(),
        "--output-format".into(),
        "stream-json".into(),
        // Container confinement is the boundary, so tools run unprompted.
        "--approval-mode".into(),
        "yolo".into(),
        // An explicit model skips the routing classifier's extra request.
        "--model".into(),
        model_id.to_owned(),
        "--skip-trust".into(),
    ];
    let mut environment: BTreeMap<String, String> = [
        ("HOME", home),
        ("GEMINI_CLI_HOME", home),
        (
            "GEMINI_CLI_SYSTEM_SETTINGS_PATH",
            system_settings.to_str().context("Gemini settings UTF8")?,
        ),
        ("GEMINI_CLI_TRUST_WORKSPACE", "true"),
        // One process with the given argv; no self-relaunch.
        ("GEMINI_CLI_NO_RELAUNCH", "true"),
        // The keychain is absent; the login stays a plain file (SBX19).
        ("GEMINI_FORCE_FILE_STORAGE", "true"),
        ("PATH", "/usr/local/bin:/usr/bin:/bin"),
    ]
    .into_iter()
    .map(|(k, v)| (k.to_owned(), v.to_owned()))
    .collect();
    let auth_type = apply_auth(auth, &mut environment)?;
    Ok(GeminiRecipe {
        executable: node.to_owned(),
        arguments,
        environment,
        working_directory: workspace.to_owned(),
        system_settings_json: serde_json::to_vec_pretty(&system_settings_json(auth_type))?,
    })
}

impl GeminiPaths<'_> {
    fn validate(self) -> Result<()> {
        let Self {
            node,
            script,
            workspace,
            private_home,
            system_settings_dir,
        } = self;
        for path in [node, script, workspace, private_home, system_settings_dir] {
            ensure!(
                recipe::normalized(path),
                "Gemini recipe requires absolute normalized paths"
            );
        }
        ensure!(
            recipe::disjoint(private_home, workspace),
            "Gemini private home must be disjoint from the workspace"
        );
        ensure!(
            [private_home, workspace]
                .into_iter()
                .all(|other| { recipe::disjoint(system_settings_dir, other) }),
            "Gemini system settings must be outside the agent home and workspace"
        );
        Ok(())
    }
}

fn validate_settings(
    harness: &HarnessSettings,
    model: &ModelSettings,
    mode: ConfinementMode,
) -> Result<()> {
    ensure!(
        harness.harness.as_str() == "gemini"
            && harness.cli_version.as_str() == GEMINI_CLI_VERSION
            && model.provider.as_str() == "google"
            && model.spending_budget.is_none(),
        "Gemini recipe unsupported settings"
    );
    let reasoning = model.reasoning.as_str();
    ensure!(
        reasoning == "default",
        "Gemini recipe unsupported reasoning {reasoning:?}: expected default"
    );
    let declares = |id| recipe::declares(harness, id);
    ensure!(
        mode == ConfinementMode::Container
            && declares(CONTAINER_CONFINEMENT_CAPABILITY)
            && !declares(NATIVE_CONFINEMENT_CAPABILITY),
        "Gemini runs only under declared container confinement"
    );
    let model_id = model.model.as_str();
    ensure!(
        !model_id.is_empty()
            && model_id
                .bytes()
                .all(|b| b.is_ascii_alphanumeric() || b"-._".contains(&b)),
        "Gemini model id"
    );
    Ok(())
}
fn validate_proxy_origin(origin: &str) -> Result<()> {
    let url = reqwest::Url::parse(origin).context("Gemini proxy origin")?;
    ensure!(
        url.scheme() == "http"
            && url.host_str() == Some("127.0.0.1")
            && url.port().is_some()
            && url.path() == "/"
            && !has_extra_authority_or_query(&url)
            && origin == format!("http://127.0.0.1:{}", url.port().unwrap_or(0)),
        "Gemini proxy origin must be numeric loopback"
    );
    Ok(())
}

fn has_extra_authority_or_query(url: &reqwest::Url) -> bool {
    !url.username().is_empty() || url.password().is_some() || url.query().is_some()
}

fn apply_auth(
    auth: GeminiAuth<'_>,
    environment: &mut BTreeMap<String, String>,
) -> Result<&'static str> {
    Ok(match auth {
        GeminiAuth::ApiKeyProxy { origin, capability } => {
            validate_proxy_origin(origin)?;
            ensure!(
                is_capability(capability),
                "Gemini home accepts only the proxy's local capability"
            );
            environment.insert("GOOGLE_GEMINI_BASE_URL".into(), origin.to_owned());
            environment.insert("GEMINI_API_KEY".into(), capability.to_owned());
            "gemini-api-key"
        }
        GeminiAuth::Subscription => "oauth-personal",
    })
}

/// `aq-gemini-` followed by 64 lowercase hex digits.
pub fn is_capability(value: &str) -> bool {
    value.len() == CAPABILITY_PREFIX.len() + 64
        && value.starts_with(CAPABILITY_PREFIX)
        && value[CAPABILITY_PREFIX.len()..]
            .bytes()
            .all(|b| b.is_ascii_digit() || (b'a'..=b'f').contains(&b))
}

fn system_settings_json(auth_type: &str) -> serde_json::Value {
    serde_json::json!({
        "security": {
            "auth": { "selectedType": auth_type, "enforcedType": auth_type },
            "folderTrust": { "enabled": false },
        },
        "general": {
            "enableAutoUpdate": false,
            "enableAutoUpdateNotification": false,
            "checkpointing": { "enabled": false },
        },
        "privacy": { "usageStatisticsEnabled": false },
        "telemetry": { "enabled": false },
        "hooksConfig": { "enabled": false },
        "skills": { "enabled": false },
        "tools": { "sandbox": false },
        // Admin settings bind only from the system scope, so the workspace
        // cannot re-enable MCP servers, extensions or skills.
        "admin": {
            "mcp": { "enabled": false },
            "extensions": { "enabled": false },
            "skills": { "enabled": false },
        },
    })
}

#[cfg(test)]
mod tests;
