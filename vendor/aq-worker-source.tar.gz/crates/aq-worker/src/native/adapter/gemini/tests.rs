use super::*;
use aq_session_protocol::Text;

const CAP: &str = "aq-gemini-0123456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef";

fn settings(confinement: &str) -> (HarnessSettings, ModelSettings) {
    (
        recipe::fixture::harness("gemini", GEMINI_CLI_VERSION, confinement),
        recipe::fixture::model("google", "gemini-2.5-flash", "default"),
    )
}
fn paths() -> GeminiPaths<'static> {
    GeminiPaths {
        node: Path::new("/opt/aq/node/bin/node"),
        script: Path::new("/opt/aq/harnesses/gemini/bundle/gemini.js"),
        workspace: Path::new("/work"),
        private_home: Path::new("/home/agent/.aq/gemini"),
        system_settings_dir: Path::new("/run/aq/gemini/attempt-1"),
    }
}
fn proxy() -> GeminiAuth<'static> {
    GeminiAuth::ApiKeyProxy {
        origin: "http://127.0.0.1:4242",
        capability: CAP,
    }
}
fn container() -> (HarnessSettings, ModelSettings) {
    settings(aq_session_protocol::CONTAINER_CONFINEMENT_CAPABILITY)
}
fn flag<'a>(recipe: &'a GeminiRecipe, name: &str) -> &'a str {
    let i = recipe.arguments.iter().position(|a| a == name).unwrap();
    assert_eq!(recipe.arguments.iter().filter(|a| *a == name).count(), 1);
    &recipe.arguments[i + 1]
}
fn system(recipe: &GeminiRecipe) -> serde_json::Value {
    serde_json::from_slice(&recipe.system_settings_json).unwrap()
}

/// The recipe passes no thinking setting, so `default` is the only reasoning it
/// accepts; any other value is refused by name instead of being ignored.
#[test]
fn reasoning_default_is_the_only_accepted_value() {
    let (h, m) = container();
    let default = map(
        RecipeSettings::new(&h, &m),
        paths(),
        ConfinementMode::Container,
        proxy(),
    )
    .unwrap();
    let rendered = format!(
        "{:?} {:?} {}",
        default.arguments,
        default.environment,
        String::from_utf8_lossy(&default.system_settings_json)
    );
    assert!(!rendered.to_lowercase().contains("thinking"), "{rendered}");
    for value in ["Default", "off", "low", "medium", "high", "xhigh", "max"] {
        let mut changed = m.clone();
        changed.reasoning = Text::new(value).unwrap();
        for auth in [proxy(), GeminiAuth::Subscription] {
            let Err(refused) = map(
                RecipeSettings::new(&h, &changed),
                paths(),
                ConfinementMode::Container,
                auth,
            ) else {
                panic!("{value} accepted")
            };
            let expected = format!("unsupported reasoning {value:?}: expected default");
            assert!(format!("{refused:#}").contains(&expected), "{refused:#}");
        }
    }
}

#[test]
fn proxy_recipe_runs_bundle_node_headless_with_loopback_key_route() {
    let (h, m) = container();
    let r = map(
        RecipeSettings::new(&h, &m),
        paths(),
        ConfinementMode::Container,
        proxy(),
    )
    .unwrap();
    assert_eq!(r.executable, Path::new("/opt/aq/node/bin/node"));
    assert_eq!(r.arguments[0], "/opt/aq/harnesses/gemini/bundle/gemini.js");
    assert_eq!(r.working_directory, Path::new("/work"));
    assert_eq!(flag(&r, "-p"), "");
    assert_eq!(flag(&r, "--output-format"), "stream-json");
    assert_eq!(flag(&r, "--approval-mode"), "yolo");
    assert_eq!(flag(&r, "--model"), "gemini-2.5-flash");
    assert!(r.arguments.iter().any(|a| a == "--skip-trust"));
    assert!(!r.arguments.iter().any(|a| a == "--sandbox" || a == "-s"));
    let e = &r.environment;
    assert_eq!(e["HOME"], "/home/agent/.aq/gemini");
    assert_eq!(e["GEMINI_CLI_HOME"], "/home/agent/.aq/gemini");
    assert_eq!(
        e["GEMINI_CLI_SYSTEM_SETTINGS_PATH"],
        "/run/aq/gemini/attempt-1/system-settings.json"
    );
    assert_eq!(e["GEMINI_CLI_NO_RELAUNCH"], "true");
    assert_eq!(e["GOOGLE_GEMINI_BASE_URL"], "http://127.0.0.1:4242");
    assert_eq!(e["GEMINI_API_KEY"], CAP);
    for name in FORBIDDEN_ENVIRONMENT {
        if !matches!(*name, "GEMINI_API_KEY" | "GOOGLE_GEMINI_BASE_URL") {
            assert!(!e.contains_key(*name), "{name} set");
        }
    }
    let s = system(&r);
    assert_eq!(s["security"]["auth"]["selectedType"], "gemini-api-key");
    assert_eq!(s["security"]["auth"]["enforcedType"], "gemini-api-key");
    assert_eq!(s["hooksConfig"]["enabled"], false);
    assert_eq!(s["telemetry"]["enabled"], false);
    assert_eq!(s["privacy"]["usageStatisticsEnabled"], false);
    assert_eq!(s["general"]["enableAutoUpdate"], false);
    assert_eq!(s["admin"]["mcp"]["enabled"], false);
    assert_eq!(s["admin"]["extensions"]["enabled"], false);
    assert_eq!(s["tools"]["sandbox"], false);
}

#[test]
fn subscription_recipe_carries_no_key_variable() {
    let (h, m) = container();
    let r = map(
        RecipeSettings::new(&h, &m),
        paths(),
        ConfinementMode::Container,
        GeminiAuth::Subscription,
    )
    .unwrap();
    for name in FORBIDDEN_ENVIRONMENT {
        assert!(!r.environment.contains_key(*name), "{name} set");
    }
    assert_eq!(
        system(&r)["security"]["auth"]["enforcedType"],
        "oauth-personal"
    );
    assert_eq!(r.environment["GEMINI_FORCE_FILE_STORAGE"], "true");
}

#[test]
fn native_mode_is_refused_even_when_declared() {
    let (h, m) = settings(aq_session_protocol::NATIVE_CONFINEMENT_CAPABILITY);
    assert!(
        map(
            RecipeSettings::new(&h, &m),
            paths(),
            ConfinementMode::Native,
            proxy()
        )
        .is_err()
    );
    let (h, m) = container();
    assert!(
        map(
            RecipeSettings::new(&h, &m),
            paths(),
            ConfinementMode::Native,
            proxy()
        )
        .is_err()
    );
}

#[test]
fn refuses_wrong_settings_capability_origin_and_paths() {
    let (h, m) = container();
    let mut bad = h.clone();
    bad.cli_version = Text::new("0.66.0").unwrap();
    assert!(
        map(
            RecipeSettings::new(&bad, &m),
            paths(),
            ConfinementMode::Container,
            proxy()
        )
        .is_err()
    );
    let mut bad = m.clone();
    bad.provider = Text::new("anthropic").unwrap();
    assert!(
        map(
            RecipeSettings::new(&h, &bad),
            paths(),
            ConfinementMode::Container,
            proxy()
        )
        .is_err()
    );
    let mut bad = m.clone();
    bad.model = Text::new("gemini 2.5; rm").unwrap();
    assert!(
        map(
            RecipeSettings::new(&h, &bad),
            paths(),
            ConfinementMode::Container,
            proxy()
        )
        .is_err()
    );
    assert_unapproved_proxy_routes(RecipeSettings::new(&h, &m));
    let mut p = paths();
    p.private_home = Path::new("/work/.gemini-home");
    assert!(
        map(
            RecipeSettings::new(&h, &m),
            p,
            ConfinementMode::Container,
            proxy()
        )
        .is_err()
    );
    let mut p = paths();
    p.script = Path::new("/opt/aq/../tmp/gemini.js");
    assert!(
        map(
            RecipeSettings::new(&h, &m),
            p,
            ConfinementMode::Container,
            proxy()
        )
        .is_err()
    );
}

#[test]
fn system_settings_dir_must_be_outside_home_and_workspace() {
    let (h, m) = container();
    for dir in [
        "/home/agent/.aq/gemini/system",
        "/home/agent/.aq",
        "/work/settings",
        "/",
        "/run/aq/../x",
        "run/aq",
    ] {
        let p = GeminiPaths {
            system_settings_dir: Path::new(dir),
            ..paths()
        };
        assert!(
            map(
                RecipeSettings::new(&h, &m),
                p,
                ConfinementMode::Container,
                proxy()
            )
            .is_err(),
            "{dir} accepted"
        );
    }
}

fn assert_unapproved_proxy_routes(settings: RecipeSettings<'_>) {
    for (origin, capability) in [
        ("http://127.0.0.1:4242", "AIzaSyRealLookingKey"),
        ("https://generativelanguage.googleapis.com", CAP),
        ("http://localhost:4242", CAP),
        ("http://127.0.0.1:4242/v1beta", CAP),
        ("http://127.0.0.1", CAP),
    ] {
        let auth = GeminiAuth::ApiKeyProxy { origin, capability };
        assert!(
            map(settings, paths(), ConfinementMode::Container, auth).is_err(),
            "{origin} {capability}"
        );
    }
}
