//! Borrowed shared physical-host facts from one exact typed preparation profile.
use super::*;
pub(crate) struct PhaseScope<'a> {
    pub grant: &'a aq_session_protocol::ProfiledGrant,
    pub digest: Digest,
    pub record_revision: u64,
    pub observed_before_write_ns: u64,
    pub deadline_ns: u64,
    pub hard_deadline_ns: u64,
    pub kernel_boot_id: Uuid,
    pub guardian_id: Uuid,
    pub launch_id: Uuid,
    pub reservation_id: Uuid,
}
impl Attempt {
    pub(crate) fn phase_scope(&self) -> Result<PhaseScope<'_>> {
        // One scope for either profile: its execution and the lease its preparation accepted.
        macro_rules! scope {
            ($e:expr, $preparation:expr, $absent:literal) => {{
                let a = &$preparation.as_ref().context($absent)?;
                let a = &a.delivery.receipt.lease;
                Ok(PhaseScope {
                    grant: &$e.delivery.receipt.grant,
                    digest: $e.digest()?,
                    record_revision: $e.record_revision,
                    observed_before_write_ns: $e.observed_before_write_ns,
                    deadline_ns: $e.deadline_ns,
                    hard_deadline_ns: $e.hard_deadline_ns,
                    kernel_boot_id: $e.kernel_boot_id,
                    guardian_id: a.guardian_id,
                    launch_id: a.launch_id,
                    reservation_id: a.hold.reservation.reservation_id,
                })
            }};
        }
        match (&self.phase_execution, &self.refresh_execution) {
            (Some(e), None) => scope!(e, self.phase_preparation, "Frozen Accepted absent"),
            (None, Some(e)) => scope!(e, self.refresh_preparation, "Refresh Accepted absent"),
            _ => anyhow::bail!("missing or mixed exact phase execution"),
        }
    }
}
impl Journal {
    pub(crate) fn check_native_execution(
        &self,
        id: Uuid,
        digest: &Digest,
        (deadline, hard): (u64, u64),
    ) -> Result<()> {
        let a = self
            .state
            .attempts
            .get(&id)
            .context("phase attempt absent")?;
        match (a.phase_execution.is_some(), a.refresh_execution.is_some()) {
            (true, false) => self.check_phase_execution(id, digest, deadline, hard),
            (false, true) => self.check_refresh_execution(id, digest, deadline, hard),
            _ => anyhow::bail!("missing or mixed exact phase execution"),
        }
    }
}
