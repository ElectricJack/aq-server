use super::*;
use aq_admission_sandbox::sandbox::PermitScope;
use zeroize::Zeroizing;

/// Outcome of [`Controller::retain_source_and_destroy`].
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct RetainedDestroy {
    pub confirmation: Confirmation<StoppedWriterProof>,
    pub receipts: Vec<aq_lifecycle_protocol::RetentionReceipt>,
}

impl<B: PlacementBackend, P: PermitProvider> Controller<B, P> {
    pub async fn launch(&mut self, id: Uuid, request: &P::Request) -> Result<()> {
        let mut a = self.attempt(id)?;
        self.admit_effect(&a)?;
        ensure!(
            a.phase == Phase::Accepted,
            "launch already attempted or not accepted"
        );
        a.phase = Phase::CreateIntent;
        self.save(id, a.clone())?;
        let result = self.backend.create(&a.create).await;
        let sandbox = self.backend_result(result)?;
        ensure!(
            sandbox.kind == self.backend.kind()
                && sandbox.owner == a.create.owner
                && !sandbox.backend_id.is_empty(),
            "backend returned mismatched identity"
        );
        let material = self
            .issue_launch_material(&mut a, &sandbox, request)
            .await?;
        self.validate_launch_permit(&a, &material.permit)?;
        self.save_launch_files(&a, &material.permit)?;
        a.bind_permit(&material.permit);
        let expires = material.permit.expires_at_ms;
        a.phase = Phase::MaterialIntent;
        self.save(id, a.clone())?;
        let result = self
            .backend
            .deliver_private_material(&sandbox, material.payload)
            .await;
        self.backend_result(result)?;
        a.phase = Phase::MaterialDelivered;
        self.save(id, a.clone())?;
        self.admit_effect(&a)?;
        ensure!(
            (self.clock)()? < expires,
            "delegated permit expired before start"
        );
        a.phase = Phase::StartIntent;
        self.save(id, a.clone())?;
        let result = self.backend.start_runner(&sandbox).await;
        self.backend_result(result)?;
        a.phase = Phase::Running;
        self.save(id, a)
    }
    async fn issue_launch_material(
        &mut self,
        a: &mut Attempt,
        sandbox: &SandboxIdentity,
        request: &P::Request,
    ) -> Result<IssuedMaterial> {
        let id = a.create.owner.attempt_id;
        a.sandbox = Some(sandbox.clone());
        a.phase = Phase::Created;
        self.save(id, a.clone())?;
        self.admit_effect(a)?;
        a.phase = Phase::IssueIntent;
        self.save(id, a.clone())?;
        self.provider
            .issue(request, sandbox, &a.request.manifest)
            .await
    }
    fn validate_launch_permit(&self, a: &Attempt, permit: &sandbox::DelegatedPermit) -> Result<()> {
        let id = a.create.owner.attempt_id;
        permit.validate()?;
        let now = (self.clock)()?;
        ensure!(
            permit.scope == PermitScope::Preparation
                && permit.binding.node == *self.identity()
                && permit.binding.attempt_id == id
                && permit.binding.grant_generation
                    == a.request.manifest.bindings.assignment_generation
                && permit.hard_deadline_ms == a.request.hard_deadline_ms
                && (permit.issued_at_ms..permit.expires_at_ms).contains(&now),
            "delegated permit does not authorize this preparation"
        );
        ensure!(
            !self
                .state()
                .attempts
                .values()
                .any(|other| other.permit_id == Some(permit.permit_id)
                    || other.logical_sandbox_id == Some(permit.binding.sandbox_id)
                    || other.channel_id == Some(permit.binding.channel_id)),
            "delegated permit reused"
        );
        Ok(())
    }
    fn save_launch_files(&mut self, a: &Attempt, permit: &sandbox::DelegatedPermit) -> Result<()> {
        let id = a.create.owner.attempt_id;
        // Credentials and manifest are only in private files; the snapshot holds IDs.
        // Failures here poison this invocation, preventing uncertain handoff retries.
        let permit_bytes = Zeroizing::new(serde_json::to_vec(permit)?);
        let manifest_bytes = Zeroizing::new(serde_json::to_vec(&a.request.manifest)?);
        self.journal.poisoned = true;
        self.journal
            .storage
            .write_private(&format!("permit-{id}.json"), &permit_bytes)?;
        self.journal
            .storage
            .write_private(&format!("manifest-{id}.json"), &manifest_bytes)?;
        self.journal.poisoned = false;
        Ok(())
    }
    // Preserve the durable effect intent: unavailable does not mean no VM exists.
    fn backend_result<T>(
        &mut self,
        result: std::result::Result<T, crate::backend::BackendError>,
    ) -> Result<T> {
        match result {
            Err(crate::backend::BackendError::Unavailable(_)) => {
                self.refuse(RefusalReason::BackendUnavailable)
            }
            other => other.map_err(Into::into),
        }
    }
    pub(super) fn record_proof(
        &mut self,
        id: Uuid,
        mut a: Attempt,
        proof: &StoppedWriterProof,
    ) -> Result<()> {
        ensure!(
            a.sandbox.as_ref() == Some(proof.sandbox()),
            "backend proof names another sandbox"
        );
        if proof.kind() == WriterProofKind::Destroyed && !a.authorizes_destruction(proof.sandbox())
        {
            self.journal.poisoned = true;
            anyhow::bail!("backend reported destruction without durable destroy authority");
        }
        a.phase = match proof.kind() {
            WriterProofKind::StoppedNoProcesses => Phase::Stopped,
            WriterProofKind::Destroyed => Phase::Destroyed,
        };
        a.stopped = Some(proof.clone());
        self.save(id, a)
    }
    pub async fn inspect(&mut self, id: Uuid) -> Result<InventoryEntry> {
        let a = self.attempt(id)?;
        let sandbox = a
            .sandbox
            .as_ref()
            .ok_or_else(|| anyhow::anyhow!("sandbox identity not recorded"))?;
        let inventory = self.backend.inspect(sandbox).await?;
        ensure!(
            inventory.sandbox == *sandbox
                && inventory.name == a.create.name
                && inventory.template_digest == a.create.template_digest
                && inventory.hard_deadline_ms == a.create.hard_deadline_ms,
            "backend inventory mismatch"
        );
        if a.stopped.is_some() && !inventory.writer_proof().is_confirmed() {
            self.journal.poisoned = true;
            anyhow::bail!("backend contradicted durable stopped-writer proof");
        }
        if let Confirmation::Confirmed(proof) = inventory.writer_proof() {
            self.record_proof(id, a, &proof)?;
        }
        Ok(inventory)
    }
    pub async fn stop(&mut self, id: Uuid) -> Result<Confirmation<StoppedWriterProof>> {
        let mut a = self.attempt(id)?;
        if let Some(proof) = a.stopped {
            return Ok(Confirmation::Confirmed(proof));
        }
        let sandbox = a.sandbox.clone().ok_or_else(|| {
            anyhow::anyhow!("sandbox identity not recorded; reconciliation required")
        })?;
        // SBX23: any stop may end in preservation (handoff failure). While the
        // runner is still reachable, drop only template-declared paths.
        if a.phase == Phase::Running {
            let paths = self.config.preserve.paths_for(&a.create.template_digest);
            if let Err(error) = self.backend.drop_reconstructible(&sandbox, &paths).await {
                tracing::info!(attempt=%id, ?error, "runner unreachable; reconstructible paths kept");
            }
        }
        a.phase = Phase::StopIntent;
        self.save(id, a.clone())?;
        let confirmation = self.backend.stop(&sandbox).await;
        if let Confirmation::Confirmed(proof) = &confirmation {
            self.record_proof(id, a, proof)?;
        }
        Ok(confirmation)
    }
    /// The caller supplies authenticated retention/operator authority; this
    /// method never manufactures permission to delete sandbox evidence.
    pub async fn destroy(
        &mut self,
        id: Uuid,
        authorization: &DestroyAuthorization,
    ) -> Result<Confirmation<StoppedWriterProof>> {
        let a = self.attempt(id)?;
        let sandbox = a
            .sandbox
            .clone()
            .ok_or_else(|| anyhow::anyhow!("sandbox identity not recorded"))?;
        ensure!(
            a.stopped.is_some() && authorization.authorizes(&sandbox),
            "destroy requires stopped writer and retention authority"
        );
        ensure!(
            a.cleanup.as_ref().is_none_or(
                |cleanup| (self.clock)().is_ok_and(|now| now >= cleanup.destroy_after_ms)
            ),
            "cleanup grace has not elapsed"
        );
        self.destroy_at(id, authorization).await
    }
    /// Retain the stopped sandbox's source snapshot centrally (role
    /// `source`) and destroy only under the returned CON-03 receipts. A
    /// journaled lifecycle authorization is reused, so a retried destroy does
    /// not upload again. Receipts are returned for the parking report.
    pub async fn retain_source_and_destroy<R: crate::artifact_client::ArtifactRoutes>(
        &mut self,
        id: Uuid,
        binding: &aq_lifecycle_protocol::Binding,
        source: &[u8],
        routes: &R,
    ) -> Result<RetainedDestroy> {
        let a = self.attempt(id)?;
        let sandbox = a
            .sandbox
            .clone()
            .ok_or_else(|| anyhow::anyhow!("sandbox identity not recorded"))?;
        ensure!(
            a.stopped.is_some(),
            "source retention requires a stopped writer"
        );
        let journaled = a
            .destroy_authorization
            .as_ref()
            .map(|d| d.lifecycle_receipts().to_vec())
            .filter(|r| !r.is_empty());
        let receipts = match journaled {
            Some(receipts) => receipts,
            None => vec![
                crate::artifact_client::retain_artifact(
                    routes,
                    binding,
                    aq_lifecycle_protocol::ArtifactRole::Source,
                    &format!("sandbox-source/{}", sandbox.owner.deterministic_name()),
                    source,
                )
                .await?,
            ],
        };
        let authorization =
            DestroyAuthorization::retained_lifecycle(sandbox, binding, receipts.clone())?;
        let confirmation = self.destroy(id, &authorization).await?;
        Ok(RetainedDestroy {
            confirmation,
            receipts,
        })
    }
    pub(super) async fn destroy_at(
        &mut self,
        id: Uuid,
        authorization: &DestroyAuthorization,
    ) -> Result<Confirmation<StoppedWriterProof>> {
        let mut a = self.attempt(id)?;
        let sandbox = a
            .sandbox
            .clone()
            .ok_or_else(|| anyhow::anyhow!("sandbox identity not recorded"))?;
        ensure!(
            a.stopped.is_some() && authorization.authorizes(&sandbox),
            "destroy requires stopped writer and retention authority"
        );
        if a.phase == Phase::Destroyed {
            return Ok(Confirmation::Confirmed(a.stopped.unwrap()));
        }
        a.destroy_authorization = Some(authorization.clone());
        a.phase = Phase::DestroyIntent;
        self.save(id, a.clone())?;
        let confirmation = self.backend.destroy(&sandbox, authorization).await;
        if let Confirmation::Confirmed(proof) = &confirmation {
            ensure!(
                proof.kind() == WriterProofKind::Destroyed,
                "destroy not confirmed"
            );
            self.record_proof(id, a, proof)?;
        }
        Ok(confirmation)
    }
}
impl Attempt {
    fn authorizes_destruction(&self, sandbox: &SandboxIdentity) -> bool {
        matches!(self.phase, Phase::DestroyIntent | Phase::Destroyed)
            && self
                .destroy_authorization
                .as_ref()
                .is_some_and(|auth| auth.authorizes(sandbox))
    }
    pub(super) fn bind_permit(&mut self, permit: &sandbox::DelegatedPermit) {
        self.permit_id = Some(permit.permit_id);
        self.logical_sandbox_id = Some(permit.binding.sandbox_id);
        self.channel_id = Some(permit.binding.channel_id);
        self.grant = Some(GrantMonitor {
            boot_id: permit.binding.node.boot_id,
            permit_id: permit.permit_id,
            sandbox_id: permit.binding.sandbox_id,
            channel_id: permit.binding.channel_id,
            generation: permit.binding.grant_generation,
            renewal_deadline_ms: permit.expires_at_ms,
            execution: permit.scope == PermitScope::Execution,
        });
    }
}
