# aq-worker agent guide

Build and run instructions are in [`README.md`](README.md). AQ task sessions also get the project notes in
[`.aq/PRIME.md`](.aq/PRIME.md).

## Build health

These are owner requirements (2026-11-05), the same in every AQ v2 Rust
repository. By November 2026 builds had become the bottleneck for AQ v2. In
aq-server an edit followed by one test rerun took 127 s, and CI ran every test
binary one after another. No build budget existed, so each change that made
things a little slower was locally reasonable (aq-server retrospective W72).
The rules below keep that from happening again. Follow them in interactive
sessions and in AQ task sessions.

### Interactive builds

- **Incremental.** The dev and test profiles are incremental, so a rebuild
  after an edit recompiles only what changed. Do not export
  `CARGO_INCREMENTAL=0` in an interactive session. Switching between
  incremental and non-incremental builds rebuilds the workspace crates, so stay
  on one setting per target directory. CI and one-shot builds set
  `CARGO_INCREMENTAL=0` themselves.
- **Disk cost.** `target/debug/incremental` grows to gigabytes per checkout.
  When disk is short, delete your own `target/debug/incremental`. Never touch
  another worktree's target.
- **Private target directory per worktree.** Each worktree builds into its
  own `CARGO_TARGET_DIR` (the default `./target`, or a path only that worktree
  uses). Never share a target directory across worktrees or branches. Worktrees
  produce identical artifact hashes and cargo judges freshness by mtime, so a
  shared target links another tree's code into your tests and their green
  result means nothing (aq-server retrospective W67).
- **Do not alternate `cargo build` and `cargo test` without a reason.**
  aq-worker is its own dev-dependency with extra features (`backend-conformance`,
  `synthetic-runtime`), so `cargo build` and `cargo test` compile two different
  aq-worker libraries.
  Iterate with `cargo test` on the test binary you are working on. Run
  `cargo build` only when you need a binary itself, and `cargo clippy` once at
  the end.
- **Test one binary at a time while iterating:**
  `cargo test -p aq-worker --locked --all-features --test <binary> [filter]`.
  Run the whole suite only when the task needs it.
- **Builds and tests run without a time limit.** Do not wrap `cargo` in
  `timeout`. A first build of a large crate can take a long time on a busy
  machine, so let it finish. If a test truly hangs, say so in your result with
  the command and how long you waited.

### Tests

- **New integration tests go into an existing test binary.** Add a module or
  a test function to the existing `tests/*.rs` binary for that area. Do not add
  a new `tests/*.rs` file: each one is another executable that links the whole
  library and all its dependencies. CI rejects an increase in the number of
  test binaries (see the budgets below).
- **Serialization.** A `static` mutex serializes tests only inside one test
  process. If tests must never run concurrently under a per-process runner
  such as nextest, declare a nextest test group (`.config/nextest.toml`), as
  aq-server does.

### Budgets

`build-budget.toml` holds ceilings, and `scripts/build-budget.py` (CI)
compares this tree with `origin/main`: the test binary count and each ratcheted
crate's lib lines may not be higher than on main.

| Budget | Recorded 2026-11-05 | Rule |
| --- | --- | --- |
| Integration test binaries in the workspace | 105 | May only go down. |
| Lines in one crate's lib (`src/`, minus bin targets) | target 40,000 | No crate lib may grow past the target. |
| aq-worker lib lines | 68,081 (ratchet) | Over the target until it is split into crates. May only go down. |

- Check locally with `python3 scripts/build-budget.py` (after `git fetch`).
- **When a number goes down**, nothing to do: main's lower value is the next
  limit. Pull requests do not edit `build-budget.toml` to keep a gain, so two
  pull requests never conflict on it.
- **Raising a number** needs an explicit edit of `build-budget.toml` in its own
  commit, a reason in the commit message, and the owner's review. Prefer
  moving code into another crate or tests into an existing binary.

### CI wall time

Each job in `.github/workflows/check.yml` has a budget of 10 min. The whole workflow (push to last
green job) has a budget of 20 min. `timeout-minutes` is a hang guard, not the
budget. A job that goes over budget on main is a defect, not a fact of life.
Open a task the same day with the measured times from the run and the cause.
Until the job is back under budget, do not add work to it. Fix it with caching,
parallel jobs, nextest, consolidating test binaries or a cheaper fixture, not by
raising the budget. Raising a budget needs the owner's review.

### Docker images

- **No shared cargo target cache without the touch step.** A Dockerfile that
  mounts a BuildKit cache over the cargo target directory, shared across trees,
  must run `find <path crate dirs> -type f -exec touch {} +` in the same `RUN`
  as `cargo build`, or use a cache id unique to the exact source. Without
  either, cargo's mtime check reuses another branch's build (aq-server
  458f682d).
- **Release-only settings stay out of CI images.** ThinLTO lives only in
  `[profile.release]`. Images built only for CI or tests use the `ci-image`
  profile (no LTO, workspace opt-level 0, dependencies 1;
  dropping LTO alone saves nothing on a 4-vCPU runner). aq-worker images are built by aq-server's
  `Dockerfile.worker` from the pinned source archive. Its target cache is keyed
  by the archive digest, and CI images pass `--build-arg CARGO_PROFILE=ci-image`.
  The same profile is defined in this repository's `Cargo.toml`.
